# Changelog

## 0.1.0 - 2026-08-02

- 首次以统一仓库发布樗蒲、投壶与飞花令三个 SealDice 插件。
- 新增根目录统一测试命令与 GitHub Actions。
- 新增可直接上传 SealDice 的 `releases/v0.1.0/` 单文件目录。
- 清理 macOS 元数据和本地测试路径。
