# 交给 Codex CLI 的 GitHub 发布任务

请将我下载到本机的《澄清南北·古代小游戏》统一仓库发布到 GitHub Public。

## 输入文件

优先查找：

```text
/Users/haminster/Downloads/澄清南北·古代小游戏-GitHub仓库-v0.1.0.zip
```

如果该路径不存在，只允许在 `/Users/haminster/Downloads` 中查找名称匹配：

```text
澄清南北·古代小游戏-GitHub仓库-v0.1.0*.zip
```

如果找到多个，选择修改时间最新者并在报告中注明实际路径。不要使用旧的 `澄清南北·古代小游戏.zip`，因为旧包含有 macOS 杂项且未统一仓库结构。

## 目标

创建一个公开 GitHub 仓库：

```text
nanbei-ancient-games
```

仓库内容是三个 SealDice 插件的单仓库：

```text
plugins/chupu
plugins/touhu
plugins/feihualing
releases/v0.1.0
```

并创建 GitHub Release：

```text
v0.1.0
```

Release 附件必须包含：

```text
nanbei-chupu.js
nanbei-touhu.js
nanbei-feihualing.js
SHA256SUMS.txt
```

## 安全边界

禁止：

- 读取或修改服务器；
- SSH 到 `game-server`；
- 上传密码、Token、Cookie、私钥、群聊记录或生产配置；
- 输出 GitHub Token；
- 修改全局 Git 配置；
- 覆盖已经存在的同名远程仓库；
- 强制推送；
- 删除本机其他项目；
- 将旧 ZIP 内的 `__MACOSX`、`.DS_Store`、`._*` 上传。

允许使用当前已经登录的 GitHub CLI 凭据，但不得打印凭据内容。

## 执行步骤

1. 检查输入 ZIP 存在，计算 SHA-256。
2. 解压到一个新的临时目录，确认最外层目录是 `nanbei-ancient-games`。
3. 审计仓库：
   - 不含 `.DS_Store`、`__MACOSX`、`._*`；
   - 不含 `/Users/`、`/mnt/data` 等本地绝对路径；
   - 不含服务器 IP、密码、Token、Cookie、私钥或 `.env`；
   - 三个发布 JS 与对应源码/构建产物一致；
   - `releases/v0.1.0/SHA256SUMS.txt` 可校验通过。
4. 在仓库根目录运行：

```bash
npm run check
```

必须确认三个插件共 27 项单元测试全部通过，且发布副本核验通过。若失败，停止发布并报告，不要为了“通过”而删除测试。

5. 检查：

```bash
gh auth status
git --version
gh --version
```

如果 GitHub CLI 未登录，停止并只提示我执行 `gh auth login`；不要索取或打印 Token。

6. 使用 `gh api user --jq .login` 获取当前 GitHub 用户名。
7. 检查远程仓库 `<当前用户>/nanbei-ancient-games` 是否已经存在：
   - 不存在：继续；
   - 已存在：不要覆盖、不要推送，停止并报告仓库 URL。
8. 将清理后的目录移动或复制到：

```text
/Users/haminster/Projects/nanbei-ancient-games
```

若该目录已存在且非空，不要覆盖；改用带时间戳的临时目录并报告。
9. 在仓库根目录初始化 Git：

```bash
git init -b main
git add .
git status --short
git commit -m "Initial release: chupu, touhu and feihualing v0.1.0"
```

提交前再次确认没有敏感文件。不要修改全局 `user.name` 或 `user.email`；若 Git 身份未配置，停止并报告。
10. 创建公开仓库并推送：

```bash
gh repo create nanbei-ancient-games \
  --public \
  --source=. \
  --remote=origin \
  --push \
  --description "SealDice 中古风味小游戏：樗蒲、投壶与飞花令"
```

11. 创建 Release：

```bash
gh release create v0.1.0 \
  releases/v0.1.0/nanbei-chupu.js \
  releases/v0.1.0/nanbei-touhu.js \
  releases/v0.1.0/nanbei-feihualing.js \
  releases/v0.1.0/SHA256SUMS.txt \
  --title "澄清南北·古代小游戏 v0.1.0" \
  --notes-file RELEASE_NOTES_v0.1.0.md
```

12. 验证：
   - 仓库 visibility 是 `PUBLIC`；
   - 默认分支是 `main`；
   - README、LICENSE、三个插件目录和 Release 附件均可见；
   - GitHub Actions 已触发；
   - 等待本次 CI 结束，并确认 `npm run check` 通过；
   - 本地 `git status --short` 为空；
   - 远程 `main` 与本地 HEAD 一致。

## 最终报告

报告必须包含：

1. 使用的 ZIP 路径与 SHA-256；
2. 本地仓库路径；
3. GitHub 仓库 URL；
4. 仓库 visibility；
5. 首次提交哈希；
6. Release URL；
7. 四个 Release 附件及 SHA-256；
8. 本地测试结果；
9. GitHub Actions 结果与运行 URL；
10. 敏感信息扫描结果；
11. `git status` 是否干净；
12. 是否对服务器或生产 SealDice 做过任何修改。

最终结论只能选择：

A. Public 仓库、Release 和 CI 均已完成并验证通过
B. 本地仓库准备完成，但 GitHub CLI 未登录，未发布
C. 同名远程仓库已经存在，为防止覆盖而停止
D. 测试或安全审计失败，未发布
E. GitHub 创建或推送失败，未强制重试
