// ==UserScript==
// @name         澄清南北·樗蒲
// @author       澄清南北
// @version      0.1.0
// @description  五木呼卢与群聊多人斗彩。仅供娱乐，不连接游戏资源。
// @timestamp    1785697200
// @license      0BSD
// ==/UserScript==

(function () {
  'use strict';

  const EXT_NAME = 'nanbei-chupu';
  const EXT_VERSION = '0.1.0';
  const STORAGE_PREFIX = 'chupu-game-v1:';
  const DEFAULT_ROUNDS = 3;
  const MIN_ROUNDS = 1;
  const MAX_ROUNDS = 9;
  const MAX_PLAYERS = 12;
  const STALE_MS = 24 * 60 * 60 * 1000;
  const QUICK_COOLDOWN_MS = 3000;
  const MAX_ROYAL_CHAIN = 20;

  const CASTS = Object.freeze({
    卢: Object.freeze({ name: '卢', score: 16, royal: true, rank: 10 }),
    雉: Object.freeze({ name: '雉', score: 14, royal: true, rank: 9 }),
    开: Object.freeze({ name: '开', score: 12, royal: false, rank: 8 }),
    塞: Object.freeze({ name: '塞', score: 11, royal: false, rank: 7 }),
    犊: Object.freeze({ name: '犊', score: 10, royal: true, rank: 6 }),
    白: Object.freeze({ name: '白', score: 8, royal: true, rank: 5 }),
    塔: Object.freeze({ name: '塔', score: 5, royal: false, rank: 4 }),
    秃: Object.freeze({ name: '秃', score: 4, royal: false, rank: 3 }),
    撅: Object.freeze({ name: '撅', score: 3, royal: false, rank: 2 }),
    枭: Object.freeze({ name: '枭', score: 2, royal: false, rank: 1 }),
  });

  const CAST_COMMENTS = Object.freeze({
    卢: [
      '五木尽玄，满座呼卢。',
      '王采之首，一掷压席。',
      '黑采俱见，今日声势极盛。',
    ],
    雉: [
      '喝雉得彩，亦是席间上乘。',
      '双雉并见，众客皆为之侧目。',
      '虽未成卢，已足称雄。',
    ],
    犊: [
      '黑犊成采，仍属王采。',
      '双犊伏案，得以再投。',
      '此采沉稳，后势尚长。',
    ],
    白: [
      '五木皆白，清采照席。',
      '白采虽静，亦列王采。',
      '一案素白，仍可乘势再投。',
    ],
    开: [
      '门户既开，宜乘势而进。',
      '开采得中，局面渐明。',
      '一雉一犊，三白相从，是为开。',
    ],
    塞: [
      '关塞当前，胜负仍未可知。',
      '塞采虽高，宜防后手。',
      '一雉一犊，余皆玄，是为塞。',
    ],
    塔: [
      '得塔五筹，守成尚可。',
      '塔采平稳，静候来局。',
      '此采不显，却也未失。',
    ],
    秃: [
      '得秃四筹，且收此局。',
      '采势稍薄，仍可徐图。',
      '席间无常，后投或能转运。',
    ],
    撅: [
      '得撅三筹，胜负尚在后局。',
      '杂采虽微，不妨再观。',
      '此投平平，且看诸君后来。',
    ],
    枭: [
      '得枭二筹，本投势弱。',
      '末采既出，宜待后举。',
      '此局未利，史官姑且记下。',
    ],
  });

  const quickCooldowns = new Map();

  function safeRandom(randomFn) {
    const value = Number(randomFn());
    if (!Number.isFinite(value)) return Math.random();
    if (value <= 0) return 0;
    if (value >= 1) return 0.999999999999;
    return value;
  }

  function randomBit(randomFn) {
    return safeRandom(randomFn) < 0.5 ? 0 : 1; // 0=白，1=玄
  }

  function shuffle(items, randomFn) {
    const output = items.slice();
    for (let i = output.length - 1; i > 0; i -= 1) {
      const j = Math.floor(safeRandom(randomFn) * (i + 1));
      const tmp = output[i];
      output[i] = output[j];
      output[j] = tmp;
    }
    return output;
  }

  /**
   * 两枚有字木：白面刻雉，黑面刻牛。
   * 三枚素木：白面为白，黑面为玄。
   *
   * bits[0..1] 为有字木，bits[2..4] 为素木；
   * 0 表示白面，1 表示黑面。
   */
  function classifyBits(bits) {
    if (!Array.isArray(bits) || bits.length !== 5) {
      throw new Error('五木必须恰有五枚');
    }
    if (bits.some((bit) => bit !== 0 && bit !== 1)) {
      throw new Error('五木每一面只能是0或1');
    }

    const markedWhite = (bits[0] === 0 ? 1 : 0) + (bits[1] === 0 ? 1 : 0);
    const plainBlack = bits[2] + bits[3] + bits[4];
    const totalBlack = bits.reduce((sum, bit) => sum + bit, 0);

    let castName;
    if (totalBlack === 5) castName = '卢';
    else if (totalBlack === 0) castName = '白';
    else if (markedWhite === 2 && plainBlack === 3) castName = '雉';
    else if (markedWhite === 0 && plainBlack === 0) castName = '犊';
    else if (markedWhite === 1 && plainBlack === 0) castName = '开';
    else if (markedWhite === 1 && plainBlack === 3) castName = '塞';
    else if (markedWhite === 2 && plainBlack === 1) castName = '塔';
    else if (markedWhite === 0 && plainBlack === 2) castName = '秃';
    else if (totalBlack === 2) castName = '撅';
    else if (totalBlack === 3) castName = '枭';
    else throw new Error(`无法识别的五木组合: ${bits.join('')}`);

    const cast = CASTS[castName];
    const faces = [
      bits[0] === 0 ? '雉' : '牛',
      bits[1] === 0 ? '雉' : '牛',
      bits[2] === 0 ? '白' : '玄',
      bits[3] === 0 ? '白' : '玄',
      bits[4] === 0 ? '白' : '玄',
    ];

    return {
      bits: bits.slice(),
      faces,
      name: cast.name,
      score: cast.score,
      royal: cast.royal,
      rank: cast.rank,
    };
  }

  function throwFiveWoods(randomFn = Math.random) {
    const bits = [
      randomBit(randomFn),
      randomBit(randomFn),
      randomBit(randomFn),
      randomBit(randomFn),
      randomBit(randomFn),
    ];
    const result = classifyBits(bits);
    result.displayFaces = shuffle(result.faces, randomFn);
    return result;
  }

  function pick(items, randomFn = Math.random) {
    if (!Array.isArray(items) || items.length === 0) return '';
    const index = Math.floor(safeRandom(randomFn) * items.length);
    return items[index];
  }

  function formatFaces(result) {
    const faces = result.displayFaces || result.faces;
    return faces.map((face) => `【${face}】`).join('');
  }

  function formatOneCast(result, index = 1, includeComment = true) {
    const royalMark = result.royal ? '·王采，可再投' : '';
    const lines = [
      index > 1 ? `第${index}投：${formatFaces(result)}` : formatFaces(result),
      `得采：${result.name}（${result.score}筹${royalMark}）`,
    ];
    if (includeComment) {
      lines.push(`史臣曰：${pick(CAST_COMMENTS[result.name])}`);
    }
    return lines.join('\n');
  }

  function rollRoyalChain(randomFn = Math.random, maxChain = MAX_ROYAL_CHAIN) {
    const rolls = [];
    let total = 0;

    for (let i = 0; i < maxChain; i += 1) {
      const result = throwFiveWoods(randomFn);
      rolls.push(result);
      total += result.score;
      if (!result.royal) break;
    }

    return {
      rolls,
      total,
      safetyStopped: rolls.length === maxChain && rolls[rolls.length - 1].royal,
    };
  }

  function createGame(hostId, hostName, rounds = DEFAULT_ROUNDS, now = Date.now()) {
    return {
      schemaVersion: 1,
      phase: 'lobby',
      hostId,
      hostName,
      rounds,
      currentRound: 1,
      players: [
        {
          id: hostId,
          name: hostName,
          score: 0,
          roundScores: [],
          rolled: false,
        },
      ],
      createdAt: now,
      updatedAt: now,
    };
  }

  function addPlayer(game, userId, name, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '对局已经开始，不能中途加入。' };
    const existing = game.players.find((player) => player.id === userId);
    if (existing) {
      existing.name = name;
      game.updatedAt = now;
      return { ok: false, error: '你已经在席中。' };
    }
    if (game.players.length >= MAX_PLAYERS) {
      return { ok: false, error: `本局最多允许${MAX_PLAYERS}人。` };
    }
    game.players.push({
      id: userId,
      name,
      score: 0,
      roundScores: [],
      rolled: false,
    });
    game.updatedAt = now;
    return { ok: true };
  }

  function removePlayer(game, userId, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '对局已经开始，不能中途退出。' };
    if (userId === game.hostId) return { ok: false, error: '开局者不能直接退出，请使用“.樗蒲 结束”。' };
    const index = game.players.findIndex((player) => player.id === userId);
    if (index < 0) return { ok: false, error: '你尚未加入本局。' };
    game.players.splice(index, 1);
    game.updatedAt = now;
    return { ok: true };
  }

  function startGame(game, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '本局已经开始。' };
    if (game.players.length < 2) return { ok: false, error: '至少需要两人入席才能开始。' };
    game.phase = 'playing';
    game.currentRound = 1;
    for (const player of game.players) player.rolled = false;
    game.updatedAt = now;
    return { ok: true };
  }

  function applyTurn(game, userId, name, randomFn = Math.random, now = Date.now()) {
    if (game.phase !== 'playing') return { ok: false, error: '当前没有正在投彩的对局。' };
    const player = game.players.find((item) => item.id === userId);
    if (!player) return { ok: false, error: '你不在本局席中。' };
    if (player.rolled) return { ok: false, error: `你在第${game.currentRound}轮已经投过五木。` };

    player.name = name;
    const chain = rollRoyalChain(randomFn);
    player.score += chain.total;
    player.roundScores.push(chain.total);
    player.rolled = true;
    game.updatedAt = now;

    let roundEnded = false;
    let gameEnded = false;
    if (game.players.every((item) => item.rolled)) {
      roundEnded = true;
      if (game.currentRound >= game.rounds) {
        game.phase = 'finished';
        gameEnded = true;
      } else {
        game.currentRound += 1;
        for (const item of game.players) item.rolled = false;
      }
    }

    return {
      ok: true,
      player,
      chain,
      roundEnded,
      gameEnded,
    };
  }

  function sortedPlayers(game) {
    return game.players.slice().sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return a.name.localeCompare(b.name, 'zh-CN');
    });
  }

  function winners(game) {
    if (!game.players.length) return [];
    const maxScore = Math.max(...game.players.map((player) => player.score));
    return game.players.filter((player) => player.score === maxScore);
  }

  function formatStandings(game) {
    return sortedPlayers(game)
      .map((player, index) => {
        const mark = game.phase === 'playing' ? (player.rolled ? '已投' : '待投') : '';
        const rounds = player.roundScores.length ? `〔${player.roundScores.join('／')}〕` : '';
        return `${index + 1}. ${player.name}：${player.score}筹${rounds}${mark ? ` · ${mark}` : ''}`;
      })
      .join('\n');
  }

  function parseRounds(text) {
    if (!text) return DEFAULT_ROUNDS;
    const value = Number.parseInt(text, 10);
    if (!Number.isInteger(value) || value < MIN_ROUNDS || value > MAX_ROUNDS) return null;
    return value;
  }

  function safeKeyPart(value) {
    return encodeURIComponent(String(value || 'unknown')).slice(0, 180);
  }

  function gameStorageKey(groupId) {
    return `${STORAGE_PREFIX}${safeKeyPart(groupId)}`;
  }

  function isStale(game, now = Date.now()) {
    return !game || !Number.isFinite(game.updatedAt) || now - game.updatedAt > STALE_MS;
  }

  function isGameManager(ctx, game) {
    const userId = ctx && ctx.player ? String(ctx.player.userId || '') : '';
    const privilege = Number(ctx && ctx.privilegeLevel) || 0;
    return userId === String(game.hostId) || privilege >= 50;
  }

  const HELP_TEXT = [
    '《澄清南北·樗蒲》v0.1.0',
    '',
    '单次投彩：',
    '.呼卢',
    '',
    '多人斗彩：',
    '.樗蒲 开局 [轮数]　默认3轮，开局者自动入席',
    '.樗蒲 加入',
    '.樗蒲 退出　　　　仅开局前',
    '.樗蒲 开始　　　　开局者或群管理执行',
    '.樗蒲 投　　　　　每人每轮一次；王采会自动连投',
    '.樗蒲 状态',
    '.樗蒲 结束　　　　开局者或群管理执行',
    '.樗蒲 规则',
    '',
    '本插件采用《五木经》十采与采数，',
    '多人玩法为群聊简化斗彩，不复原完整行马棋盘。',
    '只记娱乐筹数，不连接《澄清南北》经济点或玩家资源。',
  ].join('\n');

  const RULES_TEXT = [
    '【五木】',
    '两枚有字木：白面为“雉”，黑面为“牛”；',
    '三枚素木：白面为“白”，黑面为“玄”。',
    '',
    '【王采】',
    '卢16、雉14、犊10、白8。',
    '王采投出后自动再投；连续王采可以连续再投。',
    '',
    '【杂采】',
    '开12、塞11、塔5、秃4、撅3、枭2。',
    '',
    '【多人斗彩】',
    '默认三轮。每人每轮投一次，将本轮及王采连投所得筹数相加；',
    '全部轮次结束后，总筹数最高者胜。同分则并列。',
    '',
    '这是依据古代十采制作的现代群聊简化玩法，',
    '不声称复原关、坑、矢、马俱全的完整樗蒲棋局。',
  ].join('\n');

  function registerSealDice() {
    if (typeof seal === 'undefined' || !seal.ext) return;
    if (seal.ext.find(EXT_NAME)) return;

    const ext = seal.ext.new(EXT_NAME, '澄清南北', EXT_VERSION);

    function resultDone() {
      return seal.ext.newCmdExecuteResult(true);
    }

    function reply(ctx, msg, text) {
      seal.replyToSender(ctx, msg, text);
      return resultDone();
    }

    function getIdentity(ctx) {
      return {
        userId: String(ctx && ctx.player ? ctx.player.userId || '' : ''),
        name: String(ctx && ctx.player ? ctx.player.name || '无名客' : '无名客'),
      };
    }

    function requireGroup(ctx, msg) {
      if (ctx && ctx.isPrivate) {
        reply(ctx, msg, '多人樗蒲只能在群聊中进行；私聊可使用“.呼卢”。');
        return null;
      }
      const groupId = ctx && ctx.group ? String(ctx.group.groupId || '') : '';
      if (!groupId) {
        reply(ctx, msg, '无法识别当前群聊，未建立樗蒲对局。');
        return null;
      }
      return groupId;
    }

    function loadGame(groupId) {
      const key = gameStorageKey(groupId);
      const raw = ext.storageGet(key);
      if (!raw) return null;
      try {
        const game = JSON.parse(raw);
        if (isStale(game)) {
          ext.storageSet(key, '');
          return null;
        }
        return game;
      } catch (_error) {
        ext.storageSet(key, '');
        return null;
      }
    }

    function saveGame(groupId, game) {
      ext.storageSet(gameStorageKey(groupId), JSON.stringify(game));
    }

    function clearGame(groupId) {
      ext.storageSet(gameStorageKey(groupId), '');
    }

    const cmdHulu = seal.ext.newCmdItemInfo();
    cmdHulu.name = '呼卢';
    cmdHulu.help = '单次投掷樗蒲五木。用法：呼卢';
    cmdHulu.solve = (ctx, msg) => {
      const identity = getIdentity(ctx);
      const scope = ctx && ctx.isPrivate
        ? `private:${identity.userId}`
        : `group:${ctx && ctx.group ? ctx.group.groupId : 'unknown'}:${identity.userId}`;
      const now = Date.now();
      const previous = quickCooldowns.get(scope) || 0;
      if (now - previous < QUICK_COOLDOWN_MS) {
        return reply(ctx, msg, '五木尚在杯中，请稍候片刻再投。');
      }
      quickCooldowns.set(scope, now);

      const cast = throwFiveWoods();
      return reply(
        ctx,
        msg,
        `<${identity.name}>振杯投五木——\n${formatOneCast(cast)}\n\n随机结果仅供娱乐。`
      );
    };

    const cmdChupu = seal.ext.newCmdItemInfo();
    cmdChupu.name = '樗蒲';
    cmdChupu.help = HELP_TEXT;
    cmdChupu.solve = (ctx, msg, cmdArgs) => {
      const action = String(cmdArgs.getArgN(1) || '').trim();
      if (!action || action === 'help' || action === '帮助') {
        return reply(ctx, msg, HELP_TEXT);
      }
      if (action === '规则') {
        return reply(ctx, msg, RULES_TEXT);
      }

      const groupId = requireGroup(ctx, msg);
      if (!groupId) return resultDone();

      const identity = getIdentity(ctx);
      let game = loadGame(groupId);

      if (action === '开局') {
        if (game && (game.phase === 'lobby' || game.phase === 'playing')) {
          return reply(ctx, msg, '本群已有一局樗蒲正在进行，请先结束旧局。');
        }
        const rounds = parseRounds(String(cmdArgs.getArgN(2) || '').trim());
        if (rounds === null) {
          return reply(ctx, msg, `轮数只能是${MIN_ROUNDS}至${MAX_ROUNDS}之间的整数。`);
        }
        game = createGame(identity.userId, identity.name, rounds);
        saveGame(groupId, game);
        return reply(
          ctx,
          msg,
          `${identity.name}设下樗蒲之席，自己已先入席。\n` +
          `本局共${rounds}轮，最多${MAX_PLAYERS}人。\n` +
          '其余人请发送“.樗蒲 加入”；人齐后由开局者发送“.樗蒲 开始”。'
        );
      }

      if (!game) {
        return reply(ctx, msg, '本群当前没有樗蒲对局。发送“.樗蒲 开局”即可设席。');
      }

      if (action === '加入') {
        const joined = addPlayer(game, identity.userId, identity.name);
        if (!joined.ok) return reply(ctx, msg, joined.error);
        saveGame(groupId, game);
        return reply(
          ctx,
          msg,
          `${identity.name}入席。当前共${game.players.length}人：\n` +
          game.players.map((player) => `· ${player.name}`).join('\n')
        );
      }

      if (action === '退出') {
        const removed = removePlayer(game, identity.userId);
        if (!removed.ok) return reply(ctx, msg, removed.error);
        saveGame(groupId, game);
        return reply(ctx, msg, `${identity.name}离席。当前尚有${game.players.length}人。`);
      }

      if (action === '开始') {
        if (!isGameManager(ctx, game)) {
          return reply(ctx, msg, '只有开局者、群管理或骰主可以宣布开始。');
        }
        const started = startGame(game);
        if (!started.ok) return reply(ctx, msg, started.error);
        saveGame(groupId, game);
        return reply(
          ctx,
          msg,
          `樗蒲开席，共${game.rounds}轮。\n` +
          `入席者：${game.players.map((player) => player.name).join('、')}\n\n` +
          '第一轮开始，请各自发送“.樗蒲 投”。'
        );
      }

      if (action === '投') {
        const applied = applyTurn(game, identity.userId, identity.name);
        if (!applied.ok) return reply(ctx, msg, applied.error);

        const castLines = applied.chain.rolls
          .map((cast, index) => formatOneCast(cast, index + 1, index === applied.chain.rolls.length - 1))
          .join('\n\n');

        let text =
          `<${identity.name}>振杯投五木——\n${castLines}\n\n` +
          `本次共得${applied.chain.total}筹；累计${applied.player.score}筹。`;

        if (applied.chain.safetyStopped) {
          text += `\n连续王采达到安全上限${MAX_ROYAL_CHAIN}次，本次连投在此停止。`;
        }

        if (applied.gameEnded) {
          const victors = winners(game);
          text +=
            `\n\n三巡既毕，樗蒲收席。\n${formatStandings(game)}\n\n` +
            `胜者：${victors.map((player) => player.name).join('、')}（${victors[0].score}筹）`;
        } else if (applied.roundEnded) {
          text +=
            `\n\n第${game.currentRound - 1}轮结束。\n${formatStandings(game)}\n\n` +
            `第${game.currentRound}轮开始，请各自再次发送“.樗蒲 投”。`;
        } else {
          const waiting = game.players.filter((player) => !player.rolled).map((player) => player.name);
          text += `\n\n本轮待投：${waiting.join('、')}`;
        }

        saveGame(groupId, game);
        return reply(ctx, msg, text);
      }

      if (action === '状态') {
        if (game.phase === 'lobby') {
          return reply(
            ctx,
            msg,
            `樗蒲尚未开席：${game.players.length}/${MAX_PLAYERS}人，计划${game.rounds}轮。\n` +
            `开局者：${game.hostName}\n` +
            game.players.map((player) => `· ${player.name}`).join('\n')
          );
        }
        if (game.phase === 'finished') {
          const victors = winners(game);
          return reply(
            ctx,
            msg,
            `本局已经结束。\n${formatStandings(game)}\n\n` +
            `胜者：${victors.map((player) => player.name).join('、')}（${victors[0].score}筹）`
          );
        }
        return reply(
          ctx,
          msg,
          `樗蒲进行中：第${game.currentRound}/${game.rounds}轮。\n${formatStandings(game)}`
        );
      }

      if (action === '结束') {
        if (!isGameManager(ctx, game)) {
          return reply(ctx, msg, '只有开局者、群管理或骰主可以收席。');
        }
        clearGame(groupId);
        return reply(ctx, msg, `${identity.name}命人收起五木，本局樗蒲已经结束。`);
      }

      return reply(ctx, msg, `未知操作：“${action}”。\n\n${HELP_TEXT}`);
    };

    ext.cmdMap['呼卢'] = cmdHulu;
    ext.cmdMap['呼盧'] = cmdHulu;
    ext.cmdMap['hulu'] = cmdHulu;

    ext.cmdMap['樗蒲'] = cmdChupu;
    ext.cmdMap['摴蒱'] = cmdChupu;
    ext.cmdMap['chupu'] = cmdChupu;

    seal.ext.register(ext);
  }

  const testApi = {
    CASTS,
    classifyBits,
    throwFiveWoods,
    rollRoyalChain,
    createGame,
    addPlayer,
    removePlayer,
    startGame,
    applyTurn,
    sortedPlayers,
    winners,
    formatFaces,
    parseRounds,
    isStale,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = testApi;
  }

  registerSealDice();
})();
