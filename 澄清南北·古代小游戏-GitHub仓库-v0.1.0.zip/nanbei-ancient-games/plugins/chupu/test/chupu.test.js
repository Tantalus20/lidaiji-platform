const test = require('node:test');
const assert = require('node:assert/strict');

const {
  CASTS,
  classifyBits,
  rollRoyalChain,
  createGame,
  addPlayer,
  startGame,
  applyTurn,
  winners,
  parseRounds,
  isStale,
} = require('../nanbei-chupu.js');

function bitsFromNumber(value) {
  return [
    (value >> 4) & 1,
    (value >> 3) & 1,
    (value >> 2) & 1,
    (value >> 1) & 1,
    value & 1,
  ];
}

test('32种五木微观组合全部能够归类', () => {
  for (let i = 0; i < 32; i += 1) {
    const result = classifyBits(bitsFromNumber(i));
    assert.ok(CASTS[result.name]);
    assert.equal(result.score, CASTS[result.name].score);
  }
});

test('十采概率分布符合五木组合', () => {
  const counts = {};
  for (let i = 0; i < 32; i += 1) {
    const name = classifyBits(bitsFromNumber(i)).name;
    counts[name] = (counts[name] || 0) + 1;
  }

  assert.deepEqual(counts, {
    白: 1,
    开: 2,
    塔: 3,
    撅: 9,
    犊: 1,
    枭: 9,
    秃: 3,
    塞: 2,
    雉: 1,
    卢: 1,
  });
});

test('四种王采的名称、采数和连投属性正确', () => {
  const cases = [
    [[1, 1, 1, 1, 1], '卢', 16],
    [[0, 0, 0, 0, 0], '白', 8],
    [[0, 0, 1, 1, 1], '雉', 14],
    [[1, 1, 0, 0, 0], '犊', 10],
  ];

  for (const [bits, name, score] of cases) {
    const result = classifyBits(bits);
    assert.equal(result.name, name);
    assert.equal(result.score, score);
    assert.equal(result.royal, true);
  }
});

test('六种杂采的代表组合正确', () => {
  const cases = [
    [[0, 1, 0, 0, 0], '开', 12],
    [[0, 1, 1, 1, 1], '塞', 11],
    [[0, 0, 1, 0, 0], '塔', 5],
    [[1, 1, 1, 1, 0], '秃', 4],
    [[0, 1, 1, 0, 0], '撅', 3],
    [[0, 1, 1, 1, 0], '枭', 2],
  ];

  for (const [bits, name, score] of cases) {
    const result = classifyBits(bits);
    assert.equal(result.name, name);
    assert.equal(result.score, score);
    assert.equal(result.royal, false);
  }
});

test('王采自动连投，直到出现杂采', () => {
  // 每次投掷需要5个面结果和4个洗牌随机数。
  // 先造全黑卢，再造一组开。
  const values = [
    // 卢：五个1
    0.9, 0.9, 0.9, 0.9, 0.9, 0.1, 0.2, 0.3, 0.4,
    // 开：第一枚有字白、第二枚有字黑、三枚素木白
    0.1, 0.9, 0.1, 0.1, 0.1, 0.1, 0.2, 0.3, 0.4,
  ];
  let index = 0;
  const chain = rollRoyalChain(() => values[index++], 5);
  assert.equal(chain.rolls.length, 2);
  assert.equal(chain.rolls[0].name, '卢');
  assert.equal(chain.rolls[1].name, '开');
  assert.equal(chain.total, 28);
  assert.equal(chain.safetyStopped, false);
});

test('多人房间加入、开始、每轮限投一次', () => {
  const game = createGame('u1', '甲', 1, 1000);
  assert.equal(addPlayer(game, 'u2', '乙', 1001).ok, true);
  assert.equal(startGame(game, 1002).ok, true);

  const alwaysWhite = () => 0.1; // 白，王采会继续；用max chain不可从applyTurn注入
  // 改用循环序列：第一投为开，立即停止。
  const openValues = [0.1, 0.9, 0.1, 0.1, 0.1, 0.1, 0.2, 0.3, 0.4];
  let a = 0;
  const first = applyTurn(game, 'u1', '甲', () => openValues[a++], 1003);
  assert.equal(first.ok, true);
  assert.equal(first.player.score, 12);

  const duplicate = applyTurn(game, 'u1', '甲', () => 0.1, 1004);
  assert.equal(duplicate.ok, false);

  let b = 0;
  const second = applyTurn(game, 'u2', '乙', () => openValues[b++], 1005);
  assert.equal(second.ok, true);
  assert.equal(second.gameEnded, true);
  assert.equal(game.phase, 'finished');
  assert.equal(winners(game).length, 2);
});

test('轮数解析和过期判断', () => {
  assert.equal(parseRounds(''), 3);
  assert.equal(parseRounds('1'), 1);
  assert.equal(parseRounds('9'), 9);
  assert.equal(parseRounds('0'), null);
  assert.equal(parseRounds('10'), null);
  assert.equal(parseRounds('abc'), null);

  const game = createGame('u1', '甲', 3, 1000);
  game.updatedAt = 1000;
  assert.equal(isStale(game, 1000 + 23 * 60 * 60 * 1000), false);
  assert.equal(isStale(game, 1000 + 25 * 60 * 60 * 1000), true);
});
