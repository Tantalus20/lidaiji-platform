// ==UserScript==
// @name         澄清南北·飞花令
// @author       澄清南北
// @version      0.1.0
// @description  群聊轮流令、抢答令、精选诗句库与人工裁决。
// @timestamp    1785702180
// @license      0BSD
// ==/UserScript==

(function () {
  'use strict';

  const EXT_NAME = 'nanbei-feihualing';
  const EXT_VERSION = '0.1.0';
  const STORAGE_PREFIX = 'feihualing-game-v1:';
  const STALE_MS = 24 * 60 * 60 * 1000;
  const MAX_PLAYERS = 12;
  const DEFAULT_TARGET = 5;
  const MIN_TARGET = 3;
  const MAX_TARGET = 20;
  const MAX_USED_KEYS = 500;
  const CORPUS = {"schemaVersion":1,"corpusVersion":"0.1.0","name":"澄清南北·飞花令精选诗句库","license":"Public Domain classical texts; metadata released under CC0-1.0","description":"精选常见古典诗句。未收录诗句由设席者人工裁决。","records":[{"id":"p0001","title":"静夜思","author":"李白","dynasty":"唐","lines":["床前明月光","疑是地上霜","举头望明月","低头思故乡"]},{"id":"p0002","title":"春晓","author":"孟浩然","dynasty":"唐","lines":["春眠不觉晓","处处闻啼鸟","夜来风雨声","花落知多少"]},{"id":"p0003","title":"登鹳雀楼","author":"王之涣","dynasty":"唐","lines":["白日依山尽","黄河入海流","欲穷千里目","更上一层楼"]},{"id":"p0004","title":"望庐山瀑布","author":"李白","dynasty":"唐","lines":["日照香炉生紫烟","遥看瀑布挂前川","飞流直下三千尺","疑是银河落九天"]},{"id":"p0005","title":"江雪","author":"柳宗元","dynasty":"唐","lines":["千山鸟飞绝","万径人踪灭","孤舟蓑笠翁","独钓寒江雪"]},{"id":"p0006","title":"相思","author":"王维","dynasty":"唐","lines":["红豆生南国","春来发几枝","愿君多采撷","此物最相思"]},{"id":"p0007","title":"九月九日忆山东兄弟","author":"王维","dynasty":"唐","lines":["独在异乡为异客","每逢佳节倍思亲","遥知兄弟登高处","遍插茱萸少一人"]},{"id":"p0008","title":"枫桥夜泊","author":"张继","dynasty":"唐","lines":["月落乌啼霜满天","江枫渔火对愁眠","姑苏城外寒山寺","夜半钟声到客船"]},{"id":"p0009","title":"早发白帝城","author":"李白","dynasty":"唐","lines":["朝辞白帝彩云间","千里江陵一日还","两岸猿声啼不住","轻舟已过万重山"]},{"id":"p0010","title":"黄鹤楼送孟浩然之广陵","author":"李白","dynasty":"唐","lines":["故人西辞黄鹤楼","烟花三月下扬州","孤帆远影碧空尽","唯见长江天际流"]},{"id":"p0011","title":"凉州词","author":"王之涣","dynasty":"唐","lines":["黄河远上白云间","一片孤城万仞山","羌笛何须怨杨柳","春风不度玉门关"]},{"id":"p0012","title":"凉州词","author":"王翰","dynasty":"唐","lines":["葡萄美酒夜光杯","欲饮琵琶马上催","醉卧沙场君莫笑","古来征战几人回"]},{"id":"p0013","title":"出塞","author":"王昌龄","dynasty":"唐","lines":["秦时明月汉时关","万里长征人未还","但使龙城飞将在","不教胡马度阴山"]},{"id":"p0014","title":"送元二使安西","author":"王维","dynasty":"唐","lines":["渭城朝雨浥轻尘","客舍青青柳色新","劝君更尽一杯酒","西出阳关无故人"]},{"id":"p0015","title":"鹿柴","author":"王维","dynasty":"唐","lines":["空山不见人","但闻人语响","返景入深林","复照青苔上"]},{"id":"p0016","title":"竹里馆","author":"王维","dynasty":"唐","lines":["独坐幽篁里","弹琴复长啸","深林人不知","明月来相照"]},{"id":"p0017","title":"山中送别","author":"王维","dynasty":"唐","lines":["山中相送罢","日暮掩柴扉","春草明年绿","王孙归不归"]},{"id":"p0018","title":"问刘十九","author":"白居易","dynasty":"唐","lines":["绿蚁新醅酒","红泥小火炉","晚来天欲雪","能饮一杯无"]},{"id":"p0019","title":"赋得古原草送别","author":"白居易","dynasty":"唐","lines":["离离原上草","一岁一枯荣","野火烧不尽","春风吹又生","远芳侵古道","晴翠接荒城","又送王孙去","萋萋满别情"]},{"id":"p0020","title":"悯农其一","author":"李绅","dynasty":"唐","lines":["春种一粒粟","秋收万颗子","四海无闲田","农夫犹饿死"]},{"id":"p0021","title":"悯农其二","author":"李绅","dynasty":"唐","lines":["锄禾日当午","汗滴禾下土","谁知盘中餐","粒粒皆辛苦"]},{"id":"p0022","title":"咏鹅","author":"骆宾王","dynasty":"唐","lines":["曲项向天歌","白毛浮绿水","红掌拨清波"]},{"id":"p0023","title":"咏柳","author":"贺知章","dynasty":"唐","lines":["碧玉妆成一树高","万条垂下绿丝绦","不知细叶谁裁出","二月春风似剪刀"]},{"id":"p0024","title":"回乡偶书","author":"贺知章","dynasty":"唐","lines":["少小离家老大回","乡音无改鬓毛衰","儿童相见不相识","笑问客从何处来"]},{"id":"p0025","title":"望天门山","author":"李白","dynasty":"唐","lines":["天门中断楚江开","碧水东流至此回","两岸青山相对出","孤帆一片日边来"]},{"id":"p0026","title":"赠汪伦","author":"李白","dynasty":"唐","lines":["李白乘舟将欲行","忽闻岸上踏歌声","桃花潭水深千尺","不及汪伦送我情"]},{"id":"p0027","title":"独坐敬亭山","author":"李白","dynasty":"唐","lines":["众鸟高飞尽","孤云独去闲","相看两不厌","只有敬亭山"]},{"id":"p0028","title":"夜宿山寺","author":"李白","dynasty":"唐","lines":["危楼高百尺","手可摘星辰","不敢高声语","恐惊天上人"]},{"id":"p0029","title":"望洞庭","author":"刘禹锡","dynasty":"唐","lines":["湖光秋月两相和","潭面无风镜未磨","遥望洞庭山水翠","白银盘里一青螺"]},{"id":"p0030","title":"乌衣巷","author":"刘禹锡","dynasty":"唐","lines":["朱雀桥边野草花","乌衣巷口夕阳斜","旧时王谢堂前燕","飞入寻常百姓家"]},{"id":"p0031","title":"竹枝词","author":"刘禹锡","dynasty":"唐","lines":["杨柳青青江水平","闻郎江上唱歌声","东边日出西边雨","道是无晴却有晴"]},{"id":"p0032","title":"浪淘沙","author":"刘禹锡","dynasty":"唐","lines":["九曲黄河万里沙","浪淘风簸自天涯","如今直上银河去","同到牵牛织女家"]},{"id":"p0033","title":"秋词","author":"刘禹锡","dynasty":"唐","lines":["自古逢秋悲寂寥","我言秋日胜春朝","晴空一鹤排云上","便引诗情到碧霄"]},{"id":"p0034","title":"石头城","author":"刘禹锡","dynasty":"唐","lines":["山围故国周遭在","潮打空城寂寞回","淮水东边旧时月","夜深还过女墙来"]},{"id":"p0035","title":"题都城南庄","author":"崔护","dynasty":"唐","lines":["去年今日此门中","人面桃花相映红","人面不知何处去","桃花依旧笑春风"]},{"id":"p0036","title":"泊秦淮","author":"杜牧","dynasty":"唐","lines":["烟笼寒水月笼沙","夜泊秦淮近酒家","商女不知亡国恨","隔江犹唱后庭花"]},{"id":"p0037","title":"清明","author":"杜牧","dynasty":"唐","lines":["清明时节雨纷纷","路上行人欲断魂","借问酒家何处有","牧童遥指杏花村"]},{"id":"p0038","title":"山行","author":"杜牧","dynasty":"唐","lines":["远上寒山石径斜","白云生处有人家","停车坐爱枫林晚","霜叶红于二月花"]},{"id":"p0039","title":"江南春","author":"杜牧","dynasty":"唐","lines":["千里莺啼绿映红","水村山郭酒旗风","南朝四百八十寺","多少楼台烟雨中"]},{"id":"p0040","title":"赤壁","author":"杜牧","dynasty":"唐","lines":["折戟沉沙铁未销","自将磨洗认前朝","东风不与周郎便","铜雀春深锁二乔"]},{"id":"p0041","title":"过华清宫","author":"杜牧","dynasty":"唐","lines":["长安回望绣成堆","山顶千门次第开","一骑红尘妃子笑","无人知是荔枝来"]},{"id":"p0042","title":"绝句","author":"杜甫","dynasty":"唐","lines":["两个黄鹂鸣翠柳","一行白鹭上青天","窗含西岭千秋雪","门泊东吴万里船"]},{"id":"p0043","title":"绝句二首其一","author":"杜甫","dynasty":"唐","lines":["迟日江山丽","春风花草香","泥融飞燕子","沙暖睡鸳鸯"]},{"id":"p0044","title":"江畔独步寻花","author":"杜甫","dynasty":"唐","lines":["黄四娘家花满蹊","千朵万朵压枝低","留连戏蝶时时舞","自在娇莺恰恰啼"]},{"id":"p0045","title":"春望","author":"杜甫","dynasty":"唐","lines":["国破山河在","城春草木深","感时花溅泪","恨别鸟惊心","烽火连三月","家书抵万金","白头搔更短","浑欲不胜簪"]},{"id":"p0046","title":"登高","author":"杜甫","dynasty":"唐","lines":["风急天高猿啸哀","渚清沙白鸟飞回","无边落木萧萧下","不尽长江滚滚来","万里悲秋常作客","百年多病独登台","艰难苦恨繁霜鬓","潦倒新停浊酒杯"]},{"id":"p0047","title":"闻官军收河南河北","author":"杜甫","dynasty":"唐","lines":["剑外忽传收蓟北","初闻涕泪满衣裳","却看妻子愁何在","漫卷诗书喜欲狂","白日放歌须纵酒","青春作伴好还乡","即从巴峡穿巫峡","便下襄阳向洛阳"]},{"id":"p0048","title":"月夜忆舍弟","author":"杜甫","dynasty":"唐","lines":["戍鼓断人行","边秋一雁声","露从今夜白","月是故乡明","有弟皆分散","无家问死生","寄书长不达","况乃未休兵"]},{"id":"p0049","title":"旅夜书怀","author":"杜甫","dynasty":"唐","lines":["细草微风岸","危樯独夜舟","星垂平野阔","月涌大江流","名岂文章著","官应老病休","飘飘何所似","天地一沙鸥"]},{"id":"p0050","title":"赠花卿","author":"杜甫","dynasty":"唐","lines":["锦城丝管日纷纷","半入江风半入云","此曲只应天上有","人间能得几回闻"]},{"id":"p0051","title":"蜀相","author":"杜甫","dynasty":"唐","lines":["丞相祠堂何处寻","锦官城外柏森森","映阶碧草自春色","隔叶黄鹂空好音","三顾频烦天下计","两朝开济老臣心","出师未捷身先死","长使英雄泪满襟"]},{"id":"p0052","title":"望岳","author":"杜甫","dynasty":"唐","lines":["岱宗夫如何","齐鲁青未了","造化钟神秀","阴阳割昏晓","荡胸生曾云","决眦入归鸟","会当凌绝顶","一览众山小"]},{"id":"p0053","title":"山居秋暝","author":"王维","dynasty":"唐","lines":["空山新雨后","天气晚来秋","明月松间照","清泉石上流","竹喧归浣女","莲动下渔舟","随意春芳歇","王孙自可留"]},{"id":"p0054","title":"使至塞上","author":"王维","dynasty":"唐","lines":["单车欲问边","属国过居延","征蓬出汉塞","归雁入胡天","大漠孤烟直","长河落日圆","萧关逢候骑","都护在燕然"]},{"id":"p0055","title":"鸟鸣涧","author":"王维","dynasty":"唐","lines":["人闲桂花落","夜静春山空","月出惊山鸟","时鸣春涧中"]},{"id":"p0056","title":"终南别业","author":"王维","dynasty":"唐","lines":["中岁颇好道","晚家南山陲","兴来美独往","胜事空自知","行到水穷处","坐看云起时","偶然值林叟","谈笑无还期"]},{"id":"p0057","title":"宿建德江","author":"孟浩然","dynasty":"唐","lines":["移舟泊烟渚","日暮客愁新","野旷天低树","江清月近人"]},{"id":"p0058","title":"过故人庄","author":"孟浩然","dynasty":"唐","lines":["故人具鸡黍","邀我至田家","绿树村边合","青山郭外斜","开轩面场圃","把酒话桑麻","待到重阳日","还来就菊花"]},{"id":"p0059","title":"望洞庭湖赠张丞相","author":"孟浩然","dynasty":"唐","lines":["八月湖水平","涵虚混太清","气蒸云梦泽","波撼岳阳城","欲济无舟楫","端居耻圣明","坐观垂钓者","徒有羡鱼情"]},{"id":"p0060","title":"望月怀远","author":"张九龄","dynasty":"唐","lines":["海上生明月","天涯共此时","情人怨遥夜","竟夕起相思","灭烛怜光满","披衣觉露滋","不堪盈手赠","还寝梦佳期"]},{"id":"p0061","title":"次北固山下","author":"王湾","dynasty":"唐","lines":["客路青山外","行舟绿水前","潮平两岸阔","风正一帆悬","海日生残夜","江春入旧年","乡书何处达","归雁洛阳边"]},{"id":"p0062","title":"黄鹤楼","author":"崔颢","dynasty":"唐","lines":["昔人已乘黄鹤去","此地空余黄鹤楼","黄鹤一去不复返","白云千载空悠悠","晴川历历汉阳树","芳草萋萋鹦鹉洲","日暮乡关何处是","烟波江上使人愁"]},{"id":"p0063","title":"送杜少府之任蜀州","author":"王勃","dynasty":"唐","lines":["城阙辅三秦","风烟望五津","与君离别意","同是宦游人","海内存知己","天涯若比邻","无为在歧路","儿女共沾巾"]},{"id":"p0064","title":"芙蓉楼送辛渐","author":"王昌龄","dynasty":"唐","lines":["寒雨连江夜入吴","平明送客楚山孤","洛阳亲友如相问","一片冰心在玉壶"]},{"id":"p0065","title":"闺怨","author":"王昌龄","dynasty":"唐","lines":["闺中少妇不知愁","春日凝妆上翠楼","忽见陌头杨柳色","悔教夫婿觅封侯"]},{"id":"p0066","title":"从军行","author":"王昌龄","dynasty":"唐","lines":["青海长云暗雪山","孤城遥望玉门关","黄沙百战穿金甲","不破楼兰终不还"]},{"id":"p0067","title":"塞下曲","author":"卢纶","dynasty":"唐","lines":["月黑雁飞高","单于夜遁逃","欲将轻骑逐","大雪满弓刀"]},{"id":"p0068","title":"逢雪宿芙蓉山主人","author":"刘长卿","dynasty":"唐","lines":["日暮苍山远","天寒白屋贫","柴门闻犬吠","风雪夜归人"]},{"id":"p0069","title":"滁州西涧","author":"韦应物","dynasty":"唐","lines":["独怜幽草涧边生","上有黄鹂深树鸣","春潮带雨晚来急","野渡无人舟自横"]},{"id":"p0070","title":"逢入京使","author":"岑参","dynasty":"唐","lines":["故园东望路漫漫","双袖龙钟泪不干","马上相逢无纸笔","凭君传语报平安"]},{"id":"p0071","title":"寒食","author":"韩翃","dynasty":"唐","lines":["春城无处不飞花","寒食东风御柳斜","日暮汉宫传蜡烛","轻烟散入五侯家"]},{"id":"p0072","title":"题破山寺后禅院","author":"常建","dynasty":"唐","lines":["清晨入古寺","初日照高林","曲径通幽处","禅房花木深","山光悦鸟性","潭影空人心","万籁此都寂","但余钟磬音"]},{"id":"p0073","title":"送友人","author":"李白","dynasty":"唐","lines":["青山横北郭","白水绕东城","此地一为别","孤蓬万里征","浮云游子意","落日故人情","挥手自兹去","萧萧班马鸣"]},{"id":"p0074","title":"渡荆门送别","author":"李白","dynasty":"唐","lines":["渡远荆门外","来从楚国游","山随平野尽","江入大荒流","月下飞天镜","云生结海楼","仍怜故乡水","万里送行舟"]},{"id":"p0075","title":"月下独酌","author":"李白","dynasty":"唐","lines":["花间一壶酒","独酌无相亲","举杯邀明月","对影成三人","月既不解饮","影徒随我身","暂伴月将影","行乐须及春"]},{"id":"p0076","title":"行路难","author":"李白","dynasty":"唐","lines":["金樽清酒斗十千","玉盘珍羞直万钱","停杯投箸不能食","拔剑四顾心茫然","长风破浪会有时","直挂云帆济沧海"]},{"id":"p0077","title":"将进酒","author":"李白","dynasty":"唐","lines":["君不见黄河之水天上来","奔流到海不复回","君不见高堂明镜悲白发","朝如青丝暮成雪","人生得意须尽欢","莫使金樽空对月","天生我材必有用","千金散尽还复来"]},{"id":"p0078","title":"白雪歌送武判官归京","author":"岑参","dynasty":"唐","lines":["北风卷地白草折","胡天八月即飞雪","忽如一夜春风来","千树万树梨花开","瀚海阑干百丈冰","愁云惨淡万里凝","山回路转不见君","雪上空留马行处"]},{"id":"p0079","title":"钱塘湖春行","author":"白居易","dynasty":"唐","lines":["孤山寺北贾亭西","水面初平云脚低","几处早莺争暖树","谁家新燕啄春泥","乱花渐欲迷人眼","浅草才能没马蹄","最爱湖东行不足","绿杨阴里白沙堤"]},{"id":"p0080","title":"大林寺桃花","author":"白居易","dynasty":"唐","lines":["人间四月芳菲尽","山寺桃花始盛开","长恨春归无觅处","不知转入此中来"]},{"id":"p0081","title":"忆江南","author":"白居易","dynasty":"唐","lines":["风景旧曾谙","日出江花红胜火","春来江水绿如蓝","能不忆江南"]},{"id":"p0082","title":"暮江吟","author":"白居易","dynasty":"唐","lines":["一道残阳铺水中","半江瑟瑟半江红","可怜九月初三夜","露似真珠月似弓"]},{"id":"p0083","title":"夜雨寄北","author":"李商隐","dynasty":"唐","lines":["君问归期未有期","巴山夜雨涨秋池","何当共剪西窗烛","却话巴山夜雨时"]},{"id":"p0084","title":"无题","author":"李商隐","dynasty":"唐","lines":["相见时难别亦难","东风无力百花残","春蚕到死丝方尽","蜡炬成灰泪始干","晓镜但愁云鬓改","夜吟应觉月光寒","蓬山此去无多路","青鸟殷勤为探看"]},{"id":"p0085","title":"锦瑟","author":"李商隐","dynasty":"唐","lines":["锦瑟无端五十弦","一弦一柱思华年","庄生晓梦迷蝴蝶","望帝春心托杜鹃","沧海月明珠有泪","蓝田日暖玉生烟","此情可待成追忆","只是当时已惘然"]},{"id":"p0086","title":"登乐游原","author":"李商隐","dynasty":"唐","lines":["向晚意不适","驱车登古原","夕阳无限好","只是近黄昏"]},{"id":"p0087","title":"嫦娥","author":"李商隐","dynasty":"唐","lines":["云母屏风烛影深","长河渐落晓星沉","嫦娥应悔偷灵药","碧海青天夜夜心"]},{"id":"p0088","title":"马诗","author":"李贺","dynasty":"唐","lines":["大漠沙如雪","燕山月似钩","何当金络脑","快走踏清秋"]},{"id":"p0089","title":"雁门太守行","author":"李贺","dynasty":"唐","lines":["黑云压城城欲摧","甲光向日金鳞开","角声满天秋色里","塞上燕脂凝夜紫","报君黄金台上意","提携玉龙为君死"]},{"id":"p0090","title":"客至","author":"杜甫","dynasty":"唐","lines":["舍南舍北皆春水","但见群鸥日日来","花径不曾缘客扫","蓬门今始为君开","盘飧市远无兼味","樽酒家贫只旧醅","肯与邻翁相对饮","隔篱呼取尽余杯"]},{"id":"p0091","title":"登岳阳楼","author":"杜甫","dynasty":"唐","lines":["昔闻洞庭水","今上岳阳楼","吴楚东南坼","乾坤日夜浮","亲朋无一字","老病有孤舟","戎马关山北","凭轩涕泗流"]},{"id":"p0092","title":"江南逢李龟年","author":"杜甫","dynasty":"唐","lines":["岐王宅里寻常见","崔九堂前几度闻","正是江南好风景","落花时节又逢君"]},{"id":"p0093","title":"题西林壁","author":"苏轼","dynasty":"宋","lines":["横看成岭侧成峰","远近高低各不同","不识庐山真面目","只缘身在此山中"]},{"id":"p0094","title":"饮湖上初晴后雨","author":"苏轼","dynasty":"宋","lines":["水光潋滟晴方好","山色空蒙雨亦奇","欲把西湖比西子","淡妆浓抹总相宜"]},{"id":"p0095","title":"惠崇春江晚景","author":"苏轼","dynasty":"宋","lines":["竹外桃花三两枝","春江水暖鸭先知","蒌蒿满地芦芽短","正是河豚欲上时"]},{"id":"p0096","title":"六月二十七日望湖楼醉书","author":"苏轼","dynasty":"宋","lines":["黑云翻墨未遮山","白雨跳珠乱入船","卷地风来忽吹散","望湖楼下水如天"]},{"id":"p0097","title":"赠刘景文","author":"苏轼","dynasty":"宋","lines":["荷尽已无擎雨盖","菊残犹有傲霜枝","一年好景君须记","最是橙黄橘绿时"]},{"id":"p0098","title":"水调歌头","author":"苏轼","dynasty":"宋","lines":["明月几时有","把酒问青天","不知天上宫阙","今夕是何年","人有悲欢离合","月有阴晴圆缺","此事古难全","但愿人长久","千里共婵娟"]},{"id":"p0099","title":"念奴娇赤壁怀古","author":"苏轼","dynasty":"宋","lines":["大江东去","千古风流人物","乱石穿空","惊涛拍岸","卷起千堆雪","江山如画","一时多少豪杰","人生如梦","一尊还酹江月"]},{"id":"p0100","title":"江城子密州出猎","author":"苏轼","dynasty":"宋","lines":["老夫聊发少年狂","锦帽貂裘","千骑卷平冈","会挽雕弓如满月"]},{"id":"p0101","title":"江城子乙卯正月二十日夜记梦","author":"苏轼","dynasty":"宋","lines":["十年生死两茫茫","千里孤坟","无处话凄凉","相顾无言","惟有泪千行","料得年年肠断处"]},{"id":"p0102","title":"定风波","author":"苏轼","dynasty":"宋","lines":["莫听穿林打叶声","何妨吟啸且徐行","竹杖芒鞋轻胜马","一蓑烟雨任平生","回首向来萧瑟处","也无风雨也无晴"]},{"id":"p0103","title":"浣溪沙游蕲水清泉寺","author":"苏轼","dynasty":"宋","lines":["山下兰芽短浸溪","松间沙路净无泥","萧萧暮雨子规啼","谁道人生无再少","门前流水尚能西","休将白发唱黄鸡"]},{"id":"p0104","title":"观书有感","author":"朱熹","dynasty":"宋","lines":["半亩方塘一鉴开","天光云影共徘徊","问渠那得清如许","为有源头活水来"]},{"id":"p0105","title":"春日","author":"朱熹","dynasty":"宋","lines":["胜日寻芳泗水滨","无边光景一时新","等闲识得东风面","万紫千红总是春"]},{"id":"p0106","title":"泊船瓜洲","author":"王安石","dynasty":"宋","lines":["京口瓜洲一水间","钟山只隔数重山","春风又绿江南岸","明月何时照我还"]},{"id":"p0107","title":"元日","author":"王安石","dynasty":"宋","lines":["爆竹声中一岁除","春风送暖入屠苏","千门万户曈曈日","总把新桃换旧符"]},{"id":"p0108","title":"梅花","author":"王安石","dynasty":"宋","lines":["墙角数枝梅","凌寒独自开","遥知不是雪","为有暗香来"]},{"id":"p0109","title":"登飞来峰","author":"王安石","dynasty":"宋","lines":["飞来山上千寻塔","闻说鸡鸣见日升","不畏浮云遮望眼","自缘身在最高层"]},{"id":"p0110","title":"书湖阴先生壁","author":"王安石","dynasty":"宋","lines":["茅檐长扫净无苔","花木成畦手自栽","一水护田将绿绕","两山排闼送青来"]},{"id":"p0111","title":"夏日绝句","author":"李清照","dynasty":"宋","lines":["生当作人杰","死亦为鬼雄","至今思项羽","不肯过江东"]},{"id":"p0112","title":"如梦令常记溪亭日暮","author":"李清照","dynasty":"宋","lines":["常记溪亭日暮","沉醉不知归路","兴尽晚回舟","误入藕花深处","争渡争渡","惊起一滩鸥鹭"]},{"id":"p0113","title":"如梦令昨夜雨疏风骤","author":"李清照","dynasty":"宋","lines":["昨夜雨疏风骤","浓睡不消残酒","试问卷帘人","却道海棠依旧","知否知否","应是绿肥红瘦"]},{"id":"p0114","title":"武陵春","author":"李清照","dynasty":"宋","lines":["风住尘香花已尽","日晚倦梳头","物是人非事事休","欲语泪先流","只恐双溪舴艋舟","载不动许多愁"]},{"id":"p0115","title":"醉花阴","author":"李清照","dynasty":"宋","lines":["薄雾浓云愁永昼","瑞脑销金兽","莫道不销魂","帘卷西风","人比黄花瘦"]},{"id":"p0116","title":"一剪梅","author":"李清照","dynasty":"宋","lines":["红藕香残玉簟秋","轻解罗裳","独上兰舟","云中谁寄锦书来","雁字回时","月满西楼","此情无计可消除","才下眉头","却上心头"]},{"id":"p0117","title":"渔家傲秋思","author":"范仲淹","dynasty":"宋","lines":["塞下秋来风景异","衡阳雁去无留意","长烟落日孤城闭","浊酒一杯家万里","燕然未勒归无计","羌管悠悠霜满地","将军白发征夫泪"]},{"id":"p0118","title":"苏幕遮","author":"范仲淹","dynasty":"宋","lines":["秋色连波","波上寒烟翠","山映斜阳天接水","芳草无情","更在斜阳外","明月楼高休独倚","酒入愁肠","化作相思泪"]},{"id":"p0119","title":"破阵子为陈同甫赋壮词以寄之","author":"辛弃疾","dynasty":"宋","lines":["醉里挑灯看剑","梦回吹角连营","八百里分麾下炙","五十弦翻塞外声","沙场秋点兵","了却君王天下事","赢得生前身后名","可怜白发生"]},{"id":"p0120","title":"西江月夜行黄沙道中","author":"辛弃疾","dynasty":"宋","lines":["明月别枝惊鹊","清风半夜鸣蝉","稻花香里说丰年","听取蛙声一片","七八个星天外","两三点雨山前","旧时茅店社林边","路转溪桥忽见"]},{"id":"p0121","title":"青玉案元夕","author":"辛弃疾","dynasty":"宋","lines":["东风夜放花千树","宝马雕车香满路","众里寻他千百度","蓦然回首","那人却在灯火阑珊处"]},{"id":"p0122","title":"过零丁洋","author":"文天祥","dynasty":"宋","lines":["辛苦遭逢起一经","干戈寥落四周星","山河破碎风飘絮","身世浮沉雨打萍","惶恐滩头说惶恐","零丁洋里叹零丁","人生自古谁无死","留取丹心照汗青"]},{"id":"p0123","title":"游山西村","author":"陆游","dynasty":"宋","lines":["莫笑农家腊酒浑","丰年留客足鸡豚","山重水复疑无路","柳暗花明又一村","箫鼓追随春社近","衣冠简朴古风存","从今若许闲乘月","拄杖无时夜叩门"]},{"id":"p0124","title":"示儿","author":"陆游","dynasty":"宋","lines":["死去元知万事空","但悲不见九州同","王师北定中原日","家祭无忘告乃翁"]},{"id":"p0125","title":"书愤","author":"陆游","dynasty":"宋","lines":["早岁那知世事艰","中原北望气如山","楼船夜雪瓜洲渡","铁马秋风大散关","塞上长城空自许","镜中衰鬓已先斑","出师一表真名世","千载谁堪伯仲间"]},{"id":"p0126","title":"小池","author":"杨万里","dynasty":"宋","lines":["泉眼无声惜细流","树阴照水爱晴柔","小荷才露尖尖角","早有蜻蜓立上头"]},{"id":"p0127","title":"晓出净慈寺送林子方","author":"杨万里","dynasty":"宋","lines":["毕竟西湖六月中","风光不与四时同","接天莲叶无穷碧","映日荷花别样红"]},{"id":"p0128","title":"宿新市徐公店","author":"杨万里","dynasty":"宋","lines":["篱落疏疏一径深","树头新绿未成阴","儿童急走追黄蝶","飞入菜花无处寻"]},{"id":"p0129","title":"乡村四月","author":"翁卷","dynasty":"宋","lines":["绿遍山原白满川","子规声里雨如烟","乡村四月闲人少","才了蚕桑又插田"]},{"id":"p0130","title":"墨梅","author":"王冕","dynasty":"元","lines":["我家洗砚池头树","朵朵花开淡墨痕","不要人夸好颜色","只留清气满乾坤"]},{"id":"p0131","title":"石灰吟","author":"于谦","dynasty":"明","lines":["千锤万凿出深山","烈火焚烧若等闲","粉骨碎身浑不怕","要留清白在人间"]},{"id":"p0132","title":"竹石","author":"郑燮","dynasty":"清","lines":["咬定青山不放松","立根原在破岩中","千磨万击还坚劲","任尔东西南北风"]},{"id":"p0133","title":"己亥杂诗","author":"龚自珍","dynasty":"清","lines":["浩荡离愁白日斜","吟鞭东指即天涯","落红不是无情物","化作春泥更护花"]},{"id":"p0134","title":"村居","author":"高鼎","dynasty":"清","lines":["草长莺飞二月天","拂堤杨柳醉春烟","儿童散学归来早","忙趁东风放纸鸢"]},{"id":"p0135","title":"论诗","author":"赵翼","dynasty":"清","lines":["李杜诗篇万口传","至今已觉不新鲜","江山代有才人出","各领风骚数百年"]},{"id":"p0136","title":"长歌行","author":"汉乐府","dynasty":"汉","lines":["青青园中葵","朝露待日晞","阳春布德泽","万物生光辉","少壮不努力","老大徒伤悲"]},{"id":"p0137","title":"敕勒歌","author":"北朝民歌","dynasty":"北朝","lines":["天似穹庐","笼盖四野","风吹草低见牛羊"]},{"id":"p0138","title":"木兰诗","author":"北朝民歌","dynasty":"北朝","lines":["唧唧复唧唧","木兰当户织","不闻机杼声","唯闻女叹息","万里赴戎机","关山度若飞","朔气传金柝","寒光照铁衣","将军百战死","壮士十年归"]},{"id":"p0139","title":"饮酒","author":"陶渊明","dynasty":"东晋","lines":["结庐在人境","而无车马喧","问君何能尔","心远地自偏","采菊东篱下","悠然见南山","山气日夕佳","飞鸟相与还"]},{"id":"p0140","title":"归园田居其一","author":"陶渊明","dynasty":"东晋","lines":["少无适俗韵","性本爱丘山","误落尘网中","一去三十年","羁鸟恋旧林","池鱼思故渊","久在樊笼里","复得返自然"]},{"id":"p0141","title":"归园田居其三","author":"陶渊明","dynasty":"东晋","lines":["种豆南山下","草盛豆苗稀","晨兴理荒秽","带月荷锄归","道狭草木长","夕露沾我衣","衣沾不足惜","但使愿无违"]},{"id":"p0142","title":"观沧海","author":"曹操","dynasty":"东汉","lines":["东临碣石","以观沧海","水何澹澹","山岛竦峙","树木丛生","百草丰茂","秋风萧瑟","洪波涌起","日月之行","若出其中","星汉灿烂","若出其里"]},{"id":"p0143","title":"龟虽寿","author":"曹操","dynasty":"东汉","lines":["神龟虽寿","犹有竟时","腾蛇乘雾","终为土灰","老骥伏枥","志在千里","烈士暮年","壮心不已","盈缩之期","不但在天","养怡之福","可得永年"]},{"id":"p0144","title":"短歌行","author":"曹操","dynasty":"东汉","lines":["对酒当歌","人生几何","譬如朝露","去日苦多","青青子衿","悠悠我心","但为君故","沉吟至今","山不厌高","海不厌深","周公吐哺","天下归心"]},{"id":"p0145","title":"七步诗","author":"曹植","dynasty":"三国","lines":["煮豆持作羹","漉菽以为汁","萁在釜下燃","豆在釜中泣","本自同根生","相煎何太急"]},{"id":"p0146","title":"赠从弟","author":"刘桢","dynasty":"东汉","lines":["亭亭山上松","瑟瑟谷中风","风声一何盛","松枝一何劲","冰霜正惨凄","终岁常端正","岂不罹凝寒","松柏有本性"]},{"id":"p0147","title":"入若耶溪","author":"王籍","dynasty":"南朝梁","lines":["艅艎何泛泛","空水共悠悠","阴霞生远岫","阳景逐回流","蝉噪林逾静","鸟鸣山更幽","此地动归念","长年悲倦游"]},{"id":"p0148","title":"晚登三山还望京邑","author":"谢朓","dynasty":"南朝齐","lines":["灞涘望长安","河阳视京县","白日丽飞甍","参差皆可见","余霞散成绮","澄江静如练","喧鸟覆春洲","杂英满芳甸"]},{"id":"p0149","title":"西洲曲","author":"南朝乐府","dynasty":"南朝","lines":["忆梅下西洲","折梅寄江北","单衫杏子红","双鬓鸦雏色","海水梦悠悠","君愁我亦愁","南风知我意","吹梦到西洲"]},{"id":"p0150","title":"江南","author":"汉乐府","dynasty":"汉","lines":["江南可采莲","莲叶何田田","鱼戏莲叶间","鱼戏莲叶东","鱼戏莲叶西","鱼戏莲叶南","鱼戏莲叶北"]},{"id":"p0151","title":"上邪","author":"汉乐府","dynasty":"汉","lines":["我欲与君相知","长命无绝衰","江水为竭","冬雷震震","乃敢与君绝"]},{"id":"p0152","title":"迢迢牵牛星","author":"古诗十九首","dynasty":"汉","lines":["迢迢牵牛星","皎皎河汉女","纤纤擢素手","札札弄机杼","终日不成章","泣涕零如雨","盈盈一水间","脉脉不得语"]},{"id":"p0153","title":"行行重行行","author":"古诗十九首","dynasty":"汉","lines":["行行重行行","与君生别离","相去万余里","各在天一涯","胡马依北风","越鸟巢南枝","相去日已远","衣带日已缓"]},{"id":"p0154","title":"明月何皎皎","author":"古诗十九首","dynasty":"汉","lines":["明月何皎皎","照我罗床帏","忧愁不能寐","揽衣起徘徊","客行虽云乐","不如早旋归","出户独彷徨","愁思当告谁"]},{"id":"p0155","title":"庭中有奇树","author":"古诗十九首","dynasty":"汉","lines":["庭中有奇树","绿叶发华滋","攀条折其荣","将以遗所思","馨香盈怀袖","路远莫致之","此物何足贵","但感别经时"]},{"id":"p0156","title":"涉江采芙蓉","author":"古诗十九首","dynasty":"汉","lines":["涉江采芙蓉","兰泽多芳草","采之欲遗谁","所思在远道","还顾望旧乡","长路漫浩浩","同心而离居","忧伤以终老"]},{"id":"p0157","title":"生年不满百","author":"古诗十九首","dynasty":"汉","lines":["生年不满百","常怀千岁忧","昼短苦夜长","何不秉烛游","为乐当及时","何能待来兹","愚者爱惜费","但为后世嗤"]},{"id":"p0158","title":"关雎","author":"诗经","dynasty":"先秦","lines":["关关雎鸠","在河之洲","窈窕淑女","君子好逑","参差荇菜","左右流之","寤寐求之"]},{"id":"p0159","title":"蒹葭","author":"诗经","dynasty":"先秦","lines":["蒹葭苍苍","白露为霜","所谓伊人","在水一方","溯洄从之","道阻且长","溯游从之","宛在水中央"]},{"id":"p0160","title":"桃夭","author":"诗经","dynasty":"先秦","lines":["桃之夭夭","灼灼其华","之子于归","宜其室家","有蕡其实","宜其家室"]},{"id":"p0161","title":"采薇","author":"诗经","dynasty":"先秦","lines":["昔我往矣","杨柳依依","今我来思","雨雪霏霏","行道迟迟","载渴载饥","我心伤悲","莫知我哀"]},{"id":"p0162","title":"无衣","author":"诗经","dynasty":"先秦","lines":["岂曰无衣","与子同袍","王于兴师","修我戈矛","与子同仇","与子同泽","修我矛戟","与子偕作"]}]};
  const POPULAR_KEYWORDS = ["花","月","风","云","山","水","春","秋","夜","日","雪","雨","酒","人","江","天","心","柳","鸟","城","海","河","草"];

  const TRAD_TO_SIMP = Object.freeze({
    '風':'风','雲':'云','山':'山','水':'水','月':'月','花':'花','鳥':'鸟','馬':'马',
    '國':'国','長':'长','萬':'万','東':'东','西':'西','南':'南','北':'北','門':'门',
    '關':'关','陽':'阳','陰':'阴','無':'无','見':'见','還':'还','歸':'归','離':'离',
    '綠':'绿','紅':'红','黃':'黄','裏':'里','裡':'里','臺':'台','樓':'楼','聲':'声',
    '書':'书','夢':'梦','塵':'尘','煙':'烟','飛':'飞','開':'开','來':'来','時':'时',
    '過':'过','遠':'远','發':'发','華':'华','葉':'叶','盡':'尽','舊':'旧','與':'与',
    '為':'为','應':'应','從':'从','處':'处','憶':'忆','歡':'欢','歲':'岁','幾':'几',
    '萬':'万','千':'千','尋':'寻','難':'难','愛':'爱','獨':'独','聽':'听','說':'说',
    '滿':'满','憐':'怜','覺':'觉','驚':'惊','淚':'泪','斷':'断','壺':'壶','詩':'诗',
    '詞':'词','麗':'丽','鶴':'鹤','鴻':'鸿','雁':'雁','龍':'龙','鳳':'凤','魚':'鱼',
    '樹':'树','橋':'桥','鄉':'乡','還':'还','處':'处','誰':'谁','問':'问','頭':'头',
    '當':'当','復':'复','餘':'余','佇':'伫','將':'将','軍':'军','戰':'战','鐵':'铁',
    '蘭':'兰','蘇':'苏','劉':'刘','趙':'赵','謝':'谢','顧':'顾','後':'后','宮':'宫',
    '禪':'禅','鐘':'钟','聞':'闻','曉':'晓','晝':'昼','夜':'夜','纔':'才','只':'只'
  });

  function toSimplified(text) {
    return Array.from(String(text || ''))
      .map((char) => TRAD_TO_SIMP[char] || char)
      .join('');
  }

  function normalizeText(text) {
    return toSimplified(text)
      .toLowerCase()
      .replace(/[\s，。！？；：、,.!?;:'"“”‘’（）()《》〈〉【】\[\]—…·-]+/g, '');
  }

  function splitCandidate(text) {
    return String(text || '')
      .split(/[，。！？；：、,.!?;:\n\r]+/)
      .map((part) => part.trim())
      .filter(Boolean);
  }

  function buildCorpusIndex(corpus) {
    const exact = new Map();
    const lines = [];
    const keywordCounts = new Map();

    for (const record of corpus.records || []) {
      const normalizedLines = [];
      for (const line of record.lines || []) {
        const key = normalizeText(line);
        if (key.length < 4) continue;
        const entry = {
          line,
          key,
          title: record.title,
          author: record.author,
          dynasty: record.dynasty,
          recordId: record.id,
        };
        if (!exact.has(key)) exact.set(key, entry);
        lines.push(entry);
        normalizedLines.push(entry);

        for (const char of new Set(Array.from(key))) {
          if (/[\u4e00-\u9fff]/.test(char)) {
            keywordCounts.set(char, (keywordCounts.get(char) || 0) + 1);
          }
        }
      }

      for (let i = 0; i < normalizedLines.length - 1; i += 1) {
        const a = normalizedLines[i];
        const b = normalizedLines[i + 1];
        const pairKey = a.key + b.key;
        if (!exact.has(pairKey)) {
          exact.set(pairKey, {
            line: `${a.line}，${b.line}`,
            key: pairKey,
            title: record.title,
            author: record.author,
            dynasty: record.dynasty,
            recordId: record.id,
          });
        }
      }
    }

    return { exact, lines, keywordCounts };
  }

  const CORPUS_INDEX = buildCorpusIndex(CORPUS);

  function validateKeyword(input) {
    const normalized = normalizeText(input);
    if (Array.from(normalized).length !== 1 || !/^[\u4e00-\u9fff]$/.test(normalized)) {
      return null;
    }
    return normalized;
  }

  function candidateKeys(text) {
    const parts = splitCandidate(text)
      .map(normalizeText)
      .filter((key) => key.length >= 4);
    const all = parts.slice();
    if (parts.length >= 2) all.push(parts.join(''));
    return Array.from(new Set(all));
  }

  function inspectCandidate(keyword, text, usedKeys = []) {
    const display = String(text || '').trim();
    const fullKey = normalizeText(display);
    const parts = splitCandidate(display).map(normalizeText).filter(Boolean);

    if (!display) return { ok: false, type: 'invalid', error: '请在“接”后写出诗句。' };
    if (fullKey.length < 4) return { ok: false, type: 'invalid', error: '诗句过短，至少需要四个汉字。' };
    if (fullKey.length > 60) return { ok: false, type: 'invalid', error: '诗句过长，请一次只接一至两句。' };
    if (!fullKey.includes(keyword)) {
      return { ok: false, type: 'invalid', error: `诗句中没有本席令字“${keyword}”。` };
    }

    const keys = candidateKeys(display);
    if (keys.some((key) => usedKeys.includes(key))) {
      return { ok: false, type: 'duplicate', error: '此句或其中一行已经有人用过。' };
    }

    let entry = CORPUS_INDEX.exact.get(fullKey);
    if (!entry && parts.length === 1) entry = CORPUS_INDEX.exact.get(parts[0]);
    if (!entry && parts.length >= 2) entry = CORPUS_INDEX.exact.get(parts.join(''));

    if (entry) {
      return { ok: true, type: 'known', entry, keys, display };
    }

    return {
      ok: true,
      type: 'pending',
      keys,
      display,
      message: '此句未在当前精选词库中检出，需要设席者或群管理裁决。',
    };
  }

  function createGame(hostId, hostName, keyword, mode = 'turn', target = DEFAULT_TARGET, now = Date.now()) {
    return {
      schemaVersion: 1,
      phase: 'lobby',
      hostId,
      hostName,
      keyword,
      mode,
      target,
      players: [{ id: hostId, name: hostName, score: 0 }],
      turnIndex: 0,
      usedKeys: [],
      usedDisplay: [],
      pending: null,
      winnerIds: [],
      createdAt: now,
      updatedAt: now,
    };
  }

  function addPlayer(game, userId, name, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '飞花令已经开始，不能中途入席。' };
    const existing = game.players.find((player) => player.id === userId);
    if (existing) {
      existing.name = name;
      return { ok: false, error: '你已经在席中。' };
    }
    if (game.players.length >= MAX_PLAYERS) return { ok: false, error: `本席最多${MAX_PLAYERS}人。` };
    game.players.push({ id: userId, name, score: 0 });
    game.updatedAt = now;
    return { ok: true };
  }

  function removeLobbyPlayer(game, userId, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '开席后请使用“.飞花令 认输”。' };
    if (userId === game.hostId) return { ok: false, error: '设席者不能直接退出，请结束本局。' };
    const index = game.players.findIndex((player) => player.id === userId);
    if (index < 0) return { ok: false, error: '你尚未入席。' };
    game.players.splice(index, 1);
    game.updatedAt = now;
    return { ok: true };
  }

  function startGame(game, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '本局已经开始。' };
    if (game.players.length < 2) return { ok: false, error: '至少需要两人入席。' };
    game.phase = 'playing';
    game.turnIndex = 0;
    game.updatedAt = now;
    return { ok: true };
  }

  function currentPlayer(game) {
    if (!game.players.length) return null;
    game.turnIndex = ((game.turnIndex % game.players.length) + game.players.length) % game.players.length;
    return game.players[game.turnIndex];
  }

  function advanceTurn(game) {
    if (game.players.length) game.turnIndex = (game.turnIndex + 1) % game.players.length;
  }

  function completeAcceptedAnswer(game, userId, name, display, keys, entry = null, now = Date.now()) {
    const player = game.players.find((item) => item.id === userId);
    if (!player) return { ok: false, error: '你不在本局席中。' };

    player.name = name;
    player.score += 1;
    game.usedDisplay.push(display);
    for (const key of keys) {
      if (!game.usedKeys.includes(key)) game.usedKeys.push(key);
    }
    if (game.usedKeys.length > MAX_USED_KEYS) game.usedKeys = game.usedKeys.slice(-MAX_USED_KEYS);
    game.pending = null;
    game.updatedAt = now;

    let gameEnded = false;
    if (player.score >= game.target) {
      game.phase = 'finished';
      game.winnerIds = [player.id];
      gameEnded = true;
    } else if (game.mode === 'turn') {
      advanceTurn(game);
    }

    return { ok: true, player, entry, gameEnded };
  }

  function submitAnswer(game, userId, name, text, now = Date.now()) {
    if (game.phase !== 'playing') return { ok: false, error: '当前没有正在进行的飞花令。' };
    if (game.pending) return { ok: false, error: '席上已有一句待裁决，请先认可或驳回。' };

    const player = game.players.find((item) => item.id === userId);
    if (!player) return { ok: false, error: '你不在本局席中。' };

    if (game.mode === 'turn') {
      const current = currentPlayer(game);
      if (!current || current.id !== userId) {
        return { ok: false, error: `尚未轮到你。当前应答者：${current ? current.name : '未知'}。` };
      }
    }

    const inspected = inspectCandidate(game.keyword, text, game.usedKeys);
    if (!inspected.ok) return inspected;

    if (inspected.type === 'known') {
      return {
        ...completeAcceptedAnswer(
          game,
          userId,
          name,
          inspected.display,
          inspected.keys,
          inspected.entry,
          now
        ),
        type: 'known',
        inspected,
      };
    }

    game.pending = {
      userId,
      name,
      display: inspected.display,
      keys: inspected.keys,
      submittedAt: now,
    };
    game.updatedAt = now;
    return { ok: true, type: 'pending', inspected };
  }

  function resolvePending(game, approve, now = Date.now()) {
    if (!game.pending) return { ok: false, error: '当前没有待裁决诗句。' };
    const pending = game.pending;

    if (approve) {
      const result = completeAcceptedAnswer(
        game,
        pending.userId,
        pending.name,
        pending.display,
        pending.keys,
        null,
        now
      );
      return { ...result, approved: true, pending };
    }

    game.pending = null;
    game.updatedAt = now;
    if (game.mode === 'turn') advanceTurn(game);
    return { ok: true, approved: false, pending };
  }

  function concede(game, userId, now = Date.now()) {
    if (game.phase !== 'playing') return { ok: false, error: '当前没有正在进行的飞花令。' };
    const index = game.players.findIndex((player) => player.id === userId);
    if (index < 0) return { ok: false, error: '你不在本局席中。' };

    const [removed] = game.players.splice(index, 1);
    if (game.pending && game.pending.userId === userId) game.pending = null;

    if (game.players.length === 1) {
      game.phase = 'finished';
      game.winnerIds = [game.players[0].id];
    } else if (game.players.length === 0) {
      game.phase = 'finished';
      game.winnerIds = [];
    } else {
      if (index < game.turnIndex) game.turnIndex -= 1;
      if (game.turnIndex >= game.players.length) game.turnIndex = 0;
    }

    game.updatedAt = now;
    return { ok: true, removed, gameEnded: game.phase === 'finished' };
  }

  function sortedPlayers(game) {
    return game.players.slice().sort((a, b) => b.score - a.score || a.name.localeCompare(b.name, 'zh-CN'));
  }

  function parseMode(input) {
    const value = String(input || '').trim().toLowerCase();
    if (!value || value === '轮流' || value === '輪流' || value === 'turn') return 'turn';
    if (value === '抢答' || value === '搶答' || value === 'rush') return 'rush';
    return null;
  }

  function parseTarget(input) {
    if (!input) return DEFAULT_TARGET;
    const value = Number.parseInt(String(input), 10);
    if (!Number.isInteger(value) || value < MIN_TARGET || value > MAX_TARGET) return null;
    return value;
  }

  function randomKeyword(randomFn = Math.random) {
    const candidates = POPULAR_KEYWORDS.filter((char) => (CORPUS_INDEX.keywordCounts.get(char) || 0) >= 8);
    const source = candidates.length ? candidates : POPULAR_KEYWORDS;
    return source[Math.floor(randomFn() * source.length)] || '月';
  }

  function exampleForKeyword(keyword, randomFn = Math.random) {
    const candidates = CORPUS_INDEX.lines.filter((entry) => entry.key.includes(keyword));
    if (!candidates.length) return null;
    return candidates[Math.floor(randomFn() * candidates.length)];
  }

  function safeKeyPart(value) {
    return encodeURIComponent(String(value || 'unknown')).slice(0, 180);
  }

  function gameStorageKey(groupId) {
    return `${STORAGE_PREFIX}${safeKeyPart(groupId)}`;
  }

  function isStale(game, now = Date.now()) {
    return !game || !Number.isFinite(game.updatedAt) || now - game.updatedAt > STALE_MS;
  }

  function isGameManager(ctx, game) {
    const userId = ctx && ctx.player ? String(ctx.player.userId || '') : '';
    const privilege = Number(ctx && ctx.privilegeLevel) || 0;
    return userId === String(game.hostId) || privilege >= 50;
  }

  function modeLabel(mode) {
    return mode === 'rush' ? '抢答令' : '轮流令';
  }

  function formatStandings(game) {
    return sortedPlayers(game)
      .map((player, index) => `${index + 1}. ${player.name}：${player.score}/${game.target}分`)
      .join('\n');
  }

  const HELP_TEXT = [
    '《澄清南北·飞花令》v0.1.0',
    '',
    '开席：',
    '.飞花令 开局 <令字|随机> [轮流|抢答] [目标分]',
    '.飞花令 加入',
    '.飞花令 退出　　　　仅开席前',
    '.飞花令 开始',
    '',
    '接令：',
    '.飞花令 接 <诗句>',
    '.飞花令 认输',
    '',
    '裁决与查询：',
    '.飞花令 认可　　　　认可当前未收录诗句',
    '.飞花令 驳回',
    '.飞花令 状态',
    '.飞花令 示例 [字]',
    '.飞花令 词库',
    '.飞花令 结束',
    '',
    '默认轮流令，先得5分者胜；目标分可设3至20。',
    '词库未收录的真实诗句不会直接判错，而由设席者或群管理裁决。',
  ].join('\n');

  function registerSealDice() {
    if (typeof seal === 'undefined' || !seal.ext) return;
    if (seal.ext.find(EXT_NAME)) return;

    const ext = seal.ext.new(EXT_NAME, '澄清南北', EXT_VERSION);

    function done() {
      return seal.ext.newCmdExecuteResult(true);
    }

    function reply(ctx, msg, text) {
      seal.replyToSender(ctx, msg, text);
      return done();
    }

    function identity(ctx) {
      return {
        userId: String(ctx && ctx.player ? ctx.player.userId || '' : ''),
        name: String(ctx && ctx.player ? ctx.player.name || '无名客' : '无名客'),
      };
    }

    function requireGroup(ctx, msg) {
      if (ctx && ctx.isPrivate) {
        reply(ctx, msg, '飞花令需要在群聊中设席。');
        return null;
      }
      const groupId = ctx && ctx.group ? String(ctx.group.groupId || '') : '';
      if (!groupId) {
        reply(ctx, msg, '无法识别当前群聊。');
        return null;
      }
      return groupId;
    }

    function loadGame(groupId) {
      const key = gameStorageKey(groupId);
      const raw = ext.storageGet(key);
      if (!raw) return null;
      try {
        const game = JSON.parse(raw);
        if (isStale(game)) {
          ext.storageSet(key, '');
          return null;
        }
        return game;
      } catch (_error) {
        ext.storageSet(key, '');
        return null;
      }
    }

    function saveGame(groupId, game) {
      ext.storageSet(gameStorageKey(groupId), JSON.stringify(game));
    }

    function clearGame(groupId) {
      ext.storageSet(gameStorageKey(groupId), '');
    }

    const cmd = seal.ext.newCmdItemInfo();
    cmd.name = '飞花令';
    cmd.help = HELP_TEXT;
    cmd.solve = (ctx, msg, cmdArgs) => {
      const action = String(cmdArgs.getArgN(1) || '').trim();

      if (!action || action === '帮助' || action === 'help') return reply(ctx, msg, HELP_TEXT);

      const who = identity(ctx);

      if (action === '词库' || action === '詞庫') {
        const popular = POPULAR_KEYWORDS
          .map((char) => `${char}${CORPUS_INDEX.keywordCounts.get(char) || 0}`)
          .join('、');
        return reply(
          ctx,
          msg,
          `精选词库版本：${CORPUS.corpusVersion}\n` +
          `作品记录：${CORPUS.records.length}\n` +
          `独立诗句：${CORPUS_INDEX.lines.length}\n` +
          `常用令字覆盖：${popular}\n\n` +
          '词库只用于快速自动核验；未收录诗句可由设席者人工认可。'
        );
      }

      if (action === '示例' || action === '例句') {
        const requested = String(cmdArgs.getArgN(2) || '').trim();
        const keyword = requested ? validateKeyword(requested) : randomKeyword();
        if (!keyword) return reply(ctx, msg, '示例令字必须是一个汉字。');
        const entry = exampleForKeyword(keyword);
        if (!entry) return reply(ctx, msg, `当前词库中没有找到含“${keyword}”的示例。`);
        return reply(
          ctx,
          msg,
          `令字“${keyword}”示例：\n${entry.line}\n——${entry.dynasty}·${entry.author}《${entry.title}》`
        );
      }

      const groupId = requireGroup(ctx, msg);
      if (!groupId) return done();

      let game = loadGame(groupId);

      if (action === '开局' || action === '開局') {
        if (game && (game.phase === 'lobby' || game.phase === 'playing')) {
          return reply(ctx, msg, '本群已有一席飞花令正在进行。');
        }

        const keywordInput = String(cmdArgs.getArgN(2) || '').trim();
        if (!keywordInput) {
          return reply(ctx, msg, '请指定令字，例如“.飞花令 开局 月”，或使用“随机”。');
        }
        const keyword =
          keywordInput === '随机' || keywordInput === '隨機'
            ? randomKeyword()
            : validateKeyword(keywordInput);
        if (!keyword) return reply(ctx, msg, '令字必须是一个汉字。');

        const mode = parseMode(String(cmdArgs.getArgN(3) || '').trim());
        if (!mode) return reply(ctx, msg, '模式只能是“轮流”或“抢答”。');

        const target = parseTarget(String(cmdArgs.getArgN(4) || '').trim());
        if (target === null) return reply(ctx, msg, `目标分必须是${MIN_TARGET}至${MAX_TARGET}之间的整数。`);

        game = createGame(who.userId, who.name, keyword, mode, target);
        saveGame(groupId, game);

        return reply(
          ctx,
          msg,
          `${who.name}设下飞花令之席。\n` +
          `令字：“${keyword}”\n模式：${modeLabel(mode)}\n目标：先得${target}分\n\n` +
          '设席者已自动入席，其余人发送“.飞花令 加入”；人齐后发送“.飞花令 开始”。'
        );
      }

      if (!game) return reply(ctx, msg, '本群当前没有飞花令。发送“.飞花令 开局 月”即可设席。');

      if (action === '加入') {
        const result = addPlayer(game, who.userId, who.name);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);
        return reply(ctx, msg, `${who.name}入席。当前：${game.players.map((p) => p.name).join('、')}`);
      }

      if (action === '退出' || action === '離席') {
        const result = removeLobbyPlayer(game, who.userId);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);
        return reply(ctx, msg, `${who.name}已离席。`);
      }

      if (action === '开始' || action === '開始') {
        if (!isGameManager(ctx, game)) return reply(ctx, msg, '只有设席者、群管理或骰主可以开席。');
        const result = startGame(game);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);

        const nextText =
          game.mode === 'turn'
            ? `首位应答者：${currentPlayer(game).name}`
            : '抢答已经开始，席中人皆可接令。';

        return reply(
          ctx,
          msg,
          `飞花令开席！\n令字：“${game.keyword}”\n模式：${modeLabel(game.mode)}\n${nextText}\n\n` +
          '使用“.飞花令 接 <诗句>”。'
        );
      }

      if (action === '接' || action === '答') {
        let textParts = [];
        for (let i = 2; i <= 30; i += 1) {
          const part = cmdArgs.getArgN(i);
          if (!part) break;
          textParts.push(part);
        }
        const answerText = textParts.join(' ').trim();
        const result = submitAnswer(game, who.userId, who.name, answerText);
        if (!result.ok) return reply(ctx, msg, result.error);

        saveGame(groupId, game);

        if (result.type === 'pending') {
          return reply(
            ctx,
            msg,
            `<${who.name}>接令：\n${result.inspected.display}\n\n` +
            '此句未在当前精选词库中检出，暂不判错。\n' +
            '请设席者或群管理发送“.飞花令 认可”或“.飞花令 驳回”。'
          );
        }

        const entry = result.inspected.entry;
        let text =
          `<${who.name}>接令：\n${result.inspected.display}\n\n` +
          `词库核验：${entry.dynasty}·${entry.author}《${entry.title}》\n` +
          `【接令成功】当前${result.player.score}/${game.target}分。`;

        if (result.gameEnded) {
          text += `\n\n${who.name}先得${game.target}分，本席胜负已定。`;
        } else if (game.mode === 'turn') {
          text += `\n下一位：${currentPlayer(game).name}`;
        }
        return reply(ctx, msg, text);
      }

      if (action === '认可' || action === '認可' || action === '驳回' || action === '駁回') {
        if (!isGameManager(ctx, game)) return reply(ctx, msg, '只有设席者、群管理或骰主可以裁决。');
        const approve = action === '认可' || action === '認可';
        const result = resolvePending(game, approve);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);

        if (approve) {
          let text =
            `设席者认可：\n${result.pending.display}\n\n` +
            `【接令成功】${result.player.name}当前${result.player.score}/${game.target}分。`;
          if (result.gameEnded) {
            text += `\n${result.player.name}先得${game.target}分，本席胜负已定。`;
          } else if (game.mode === 'turn') {
            text += `\n下一位：${currentPlayer(game).name}`;
          }
          return reply(ctx, msg, text);
        }

        let text = `设席者驳回：\n${result.pending.display}\n\n【本次不得分】`;
        if (game.mode === 'turn' && game.phase === 'playing') {
          text += `\n下一位：${currentPlayer(game).name}`;
        }
        return reply(ctx, msg, text);
      }

      if (action === '认输' || action === '認輸') {
        const result = concede(game, who.userId);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);

        if (result.gameEnded && game.players.length === 1) {
          return reply(ctx, msg, `${who.name}离席认输。\n胜者：${game.players[0].name}`);
        }
        return reply(ctx, msg, `${who.name}离席认输。席中尚有：${game.players.map((p) => p.name).join('、')}`);
      }

      if (action === '状态' || action === '狀態') {
        const pendingText = game.pending
          ? `\n待裁决：${game.pending.name}——${game.pending.display}`
          : '';
        const turnText =
          game.phase === 'playing' && game.mode === 'turn'
            ? `\n当前应答：${currentPlayer(game).name}`
            : '';
        const winnerText =
          game.phase === 'finished' && game.winnerIds.length
            ? `\n胜者：${game.players.filter((p) => game.winnerIds.includes(p.id)).map((p) => p.name).join('、')}`
            : '';

        return reply(
          ctx,
          msg,
          `飞花令状态：${game.phase}\n令字：“${game.keyword}”\n模式：${modeLabel(game.mode)}\n` +
          `${formatStandings(game)}${turnText}${pendingText}${winnerText}\n` +
          `已用诗句：${game.usedDisplay.length}条`
        );
      }

      if (action === '结束' || action === '結束') {
        if (!isGameManager(ctx, game)) return reply(ctx, msg, '只有设席者、群管理或骰主可以收席。');
        clearGame(groupId);
        return reply(ctx, msg, `${who.name}命人撤去酒筹，本席飞花令结束。`);
      }

      return reply(ctx, msg, `未知操作：“${action}”。\n\n${HELP_TEXT}`);
    };

    ext.cmdMap['飞花令'] = cmd;
    ext.cmdMap['飛花令'] = cmd;
    ext.cmdMap['feihua'] = cmd;

    seal.ext.register(ext);
  }

  const testApi = {
    CORPUS,
    POPULAR_KEYWORDS,
    normalizeText,
    splitCandidate,
    buildCorpusIndex,
    validateKeyword,
    candidateKeys,
    inspectCandidate,
    createGame,
    addPlayer,
    startGame,
    currentPlayer,
    submitAnswer,
    resolvePending,
    concede,
    sortedPlayers,
    parseMode,
    parseTarget,
    exampleForKeyword,
    isStale,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = testApi;
  }

  registerSealDice();
})();
