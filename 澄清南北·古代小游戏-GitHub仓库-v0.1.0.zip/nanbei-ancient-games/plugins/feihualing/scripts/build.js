const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const templatePath = path.join(root, 'src', 'nanbei-feihualing.template.js');
const corpusPath = path.join(root, 'data', 'poetry-corpus.json');
const outPath = path.join(root, 'dist', 'nanbei-feihualing.js');

const template = fs.readFileSync(templatePath, 'utf8');
const corpus = JSON.parse(fs.readFileSync(corpusPath, 'utf8'));

const counts = new Map();
for (const record of corpus.records || []) {
  for (const line of record.lines || []) {
    for (const char of new Set(Array.from(line))) {
      if (/[\u4e00-\u9fff]/.test(char)) counts.set(char, (counts.get(char) || 0) + 1);
    }
  }
}

const preferred = ['花','月','风','云','山','水','春','秋','夜','日','雪','雨','酒','人','梦','江','天','心','柳','鸟','城','海','河','草'];
const popular = preferred.filter((char) => (counts.get(char) || 0) >= 8);

const output = template
  .replace('__CORPUS__', JSON.stringify(corpus))
  .replace('__POPULAR_KEYWORDS__', JSON.stringify(popular));

if (output.includes('__CORPUS__') || output.includes('__POPULAR_KEYWORDS__')) {
  throw new Error('模板占位符未完全替换');
}

fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, output);
console.log(`Built ${outPath}`);
console.log(`Records: ${corpus.records.length}`);
console.log(`Popular keywords: ${popular.join('、')}`);
