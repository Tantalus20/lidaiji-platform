// ==UserScript==
// @name         澄清南北·飞花令
// @author       澄清南北
// @version      0.1.0
// @description  群聊轮流令、抢答令、精选诗句库与人工裁决。
// @timestamp    1785702180
// @license      0BSD
// ==/UserScript==

(function () {
  'use strict';

  const EXT_NAME = 'nanbei-feihualing';
  const EXT_VERSION = '0.1.0';
  const STORAGE_PREFIX = 'feihualing-game-v1:';
  const STALE_MS = 24 * 60 * 60 * 1000;
  const MAX_PLAYERS = 12;
  const DEFAULT_TARGET = 5;
  const MIN_TARGET = 3;
  const MAX_TARGET = 20;
  const MAX_USED_KEYS = 500;
  const CORPUS = __CORPUS__;
  const POPULAR_KEYWORDS = __POPULAR_KEYWORDS__;

  const TRAD_TO_SIMP = Object.freeze({
    '風':'风','雲':'云','山':'山','水':'水','月':'月','花':'花','鳥':'鸟','馬':'马',
    '國':'国','長':'长','萬':'万','東':'东','西':'西','南':'南','北':'北','門':'门',
    '關':'关','陽':'阳','陰':'阴','無':'无','見':'见','還':'还','歸':'归','離':'离',
    '綠':'绿','紅':'红','黃':'黄','裏':'里','裡':'里','臺':'台','樓':'楼','聲':'声',
    '書':'书','夢':'梦','塵':'尘','煙':'烟','飛':'飞','開':'开','來':'来','時':'时',
    '過':'过','遠':'远','發':'发','華':'华','葉':'叶','盡':'尽','舊':'旧','與':'与',
    '為':'为','應':'应','從':'从','處':'处','憶':'忆','歡':'欢','歲':'岁','幾':'几',
    '萬':'万','千':'千','尋':'寻','難':'难','愛':'爱','獨':'独','聽':'听','說':'说',
    '滿':'满','憐':'怜','覺':'觉','驚':'惊','淚':'泪','斷':'断','壺':'壶','詩':'诗',
    '詞':'词','麗':'丽','鶴':'鹤','鴻':'鸿','雁':'雁','龍':'龙','鳳':'凤','魚':'鱼',
    '樹':'树','橋':'桥','鄉':'乡','還':'还','處':'处','誰':'谁','問':'问','頭':'头',
    '當':'当','復':'复','餘':'余','佇':'伫','將':'将','軍':'军','戰':'战','鐵':'铁',
    '蘭':'兰','蘇':'苏','劉':'刘','趙':'赵','謝':'谢','顧':'顾','後':'后','宮':'宫',
    '禪':'禅','鐘':'钟','聞':'闻','曉':'晓','晝':'昼','夜':'夜','纔':'才','只':'只'
  });

  function toSimplified(text) {
    return Array.from(String(text || ''))
      .map((char) => TRAD_TO_SIMP[char] || char)
      .join('');
  }

  function normalizeText(text) {
    return toSimplified(text)
      .toLowerCase()
      .replace(/[\s，。！？；：、,.!?;:'"“”‘’（）()《》〈〉【】\[\]—…·-]+/g, '');
  }

  function splitCandidate(text) {
    return String(text || '')
      .split(/[，。！？；：、,.!?;:\n\r]+/)
      .map((part) => part.trim())
      .filter(Boolean);
  }

  function buildCorpusIndex(corpus) {
    const exact = new Map();
    const lines = [];
    const keywordCounts = new Map();

    for (const record of corpus.records || []) {
      const normalizedLines = [];
      for (const line of record.lines || []) {
        const key = normalizeText(line);
        if (key.length < 4) continue;
        const entry = {
          line,
          key,
          title: record.title,
          author: record.author,
          dynasty: record.dynasty,
          recordId: record.id,
        };
        if (!exact.has(key)) exact.set(key, entry);
        lines.push(entry);
        normalizedLines.push(entry);

        for (const char of new Set(Array.from(key))) {
          if (/[\u4e00-\u9fff]/.test(char)) {
            keywordCounts.set(char, (keywordCounts.get(char) || 0) + 1);
          }
        }
      }

      for (let i = 0; i < normalizedLines.length - 1; i += 1) {
        const a = normalizedLines[i];
        const b = normalizedLines[i + 1];
        const pairKey = a.key + b.key;
        if (!exact.has(pairKey)) {
          exact.set(pairKey, {
            line: `${a.line}，${b.line}`,
            key: pairKey,
            title: record.title,
            author: record.author,
            dynasty: record.dynasty,
            recordId: record.id,
          });
        }
      }
    }

    return { exact, lines, keywordCounts };
  }

  const CORPUS_INDEX = buildCorpusIndex(CORPUS);

  function validateKeyword(input) {
    const normalized = normalizeText(input);
    if (Array.from(normalized).length !== 1 || !/^[\u4e00-\u9fff]$/.test(normalized)) {
      return null;
    }
    return normalized;
  }

  function candidateKeys(text) {
    const parts = splitCandidate(text)
      .map(normalizeText)
      .filter((key) => key.length >= 4);
    const all = parts.slice();
    if (parts.length >= 2) all.push(parts.join(''));
    return Array.from(new Set(all));
  }

  function inspectCandidate(keyword, text, usedKeys = []) {
    const display = String(text || '').trim();
    const fullKey = normalizeText(display);
    const parts = splitCandidate(display).map(normalizeText).filter(Boolean);

    if (!display) return { ok: false, type: 'invalid', error: '请在“接”后写出诗句。' };
    if (fullKey.length < 4) return { ok: false, type: 'invalid', error: '诗句过短，至少需要四个汉字。' };
    if (fullKey.length > 60) return { ok: false, type: 'invalid', error: '诗句过长，请一次只接一至两句。' };
    if (!fullKey.includes(keyword)) {
      return { ok: false, type: 'invalid', error: `诗句中没有本席令字“${keyword}”。` };
    }

    const keys = candidateKeys(display);
    if (keys.some((key) => usedKeys.includes(key))) {
      return { ok: false, type: 'duplicate', error: '此句或其中一行已经有人用过。' };
    }

    let entry = CORPUS_INDEX.exact.get(fullKey);
    if (!entry && parts.length === 1) entry = CORPUS_INDEX.exact.get(parts[0]);
    if (!entry && parts.length >= 2) entry = CORPUS_INDEX.exact.get(parts.join(''));

    if (entry) {
      return { ok: true, type: 'known', entry, keys, display };
    }

    return {
      ok: true,
      type: 'pending',
      keys,
      display,
      message: '此句未在当前精选词库中检出，需要设席者或群管理裁决。',
    };
  }

  function createGame(hostId, hostName, keyword, mode = 'turn', target = DEFAULT_TARGET, now = Date.now()) {
    return {
      schemaVersion: 1,
      phase: 'lobby',
      hostId,
      hostName,
      keyword,
      mode,
      target,
      players: [{ id: hostId, name: hostName, score: 0 }],
      turnIndex: 0,
      usedKeys: [],
      usedDisplay: [],
      pending: null,
      winnerIds: [],
      createdAt: now,
      updatedAt: now,
    };
  }

  function addPlayer(game, userId, name, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '飞花令已经开始，不能中途入席。' };
    const existing = game.players.find((player) => player.id === userId);
    if (existing) {
      existing.name = name;
      return { ok: false, error: '你已经在席中。' };
    }
    if (game.players.length >= MAX_PLAYERS) return { ok: false, error: `本席最多${MAX_PLAYERS}人。` };
    game.players.push({ id: userId, name, score: 0 });
    game.updatedAt = now;
    return { ok: true };
  }

  function removeLobbyPlayer(game, userId, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '开席后请使用“.飞花令 认输”。' };
    if (userId === game.hostId) return { ok: false, error: '设席者不能直接退出，请结束本局。' };
    const index = game.players.findIndex((player) => player.id === userId);
    if (index < 0) return { ok: false, error: '你尚未入席。' };
    game.players.splice(index, 1);
    game.updatedAt = now;
    return { ok: true };
  }

  function startGame(game, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '本局已经开始。' };
    if (game.players.length < 2) return { ok: false, error: '至少需要两人入席。' };
    game.phase = 'playing';
    game.turnIndex = 0;
    game.updatedAt = now;
    return { ok: true };
  }

  function currentPlayer(game) {
    if (!game.players.length) return null;
    game.turnIndex = ((game.turnIndex % game.players.length) + game.players.length) % game.players.length;
    return game.players[game.turnIndex];
  }

  function advanceTurn(game) {
    if (game.players.length) game.turnIndex = (game.turnIndex + 1) % game.players.length;
  }

  function completeAcceptedAnswer(game, userId, name, display, keys, entry = null, now = Date.now()) {
    const player = game.players.find((item) => item.id === userId);
    if (!player) return { ok: false, error: '你不在本局席中。' };

    player.name = name;
    player.score += 1;
    game.usedDisplay.push(display);
    for (const key of keys) {
      if (!game.usedKeys.includes(key)) game.usedKeys.push(key);
    }
    if (game.usedKeys.length > MAX_USED_KEYS) game.usedKeys = game.usedKeys.slice(-MAX_USED_KEYS);
    game.pending = null;
    game.updatedAt = now;

    let gameEnded = false;
    if (player.score >= game.target) {
      game.phase = 'finished';
      game.winnerIds = [player.id];
      gameEnded = true;
    } else if (game.mode === 'turn') {
      advanceTurn(game);
    }

    return { ok: true, player, entry, gameEnded };
  }

  function submitAnswer(game, userId, name, text, now = Date.now()) {
    if (game.phase !== 'playing') return { ok: false, error: '当前没有正在进行的飞花令。' };
    if (game.pending) return { ok: false, error: '席上已有一句待裁决，请先认可或驳回。' };

    const player = game.players.find((item) => item.id === userId);
    if (!player) return { ok: false, error: '你不在本局席中。' };

    if (game.mode === 'turn') {
      const current = currentPlayer(game);
      if (!current || current.id !== userId) {
        return { ok: false, error: `尚未轮到你。当前应答者：${current ? current.name : '未知'}。` };
      }
    }

    const inspected = inspectCandidate(game.keyword, text, game.usedKeys);
    if (!inspected.ok) return inspected;

    if (inspected.type === 'known') {
      return {
        ...completeAcceptedAnswer(
          game,
          userId,
          name,
          inspected.display,
          inspected.keys,
          inspected.entry,
          now
        ),
        type: 'known',
        inspected,
      };
    }

    game.pending = {
      userId,
      name,
      display: inspected.display,
      keys: inspected.keys,
      submittedAt: now,
    };
    game.updatedAt = now;
    return { ok: true, type: 'pending', inspected };
  }

  function resolvePending(game, approve, now = Date.now()) {
    if (!game.pending) return { ok: false, error: '当前没有待裁决诗句。' };
    const pending = game.pending;

    if (approve) {
      const result = completeAcceptedAnswer(
        game,
        pending.userId,
        pending.name,
        pending.display,
        pending.keys,
        null,
        now
      );
      return { ...result, approved: true, pending };
    }

    game.pending = null;
    game.updatedAt = now;
    if (game.mode === 'turn') advanceTurn(game);
    return { ok: true, approved: false, pending };
  }

  function concede(game, userId, now = Date.now()) {
    if (game.phase !== 'playing') return { ok: false, error: '当前没有正在进行的飞花令。' };
    const index = game.players.findIndex((player) => player.id === userId);
    if (index < 0) return { ok: false, error: '你不在本局席中。' };

    const [removed] = game.players.splice(index, 1);
    if (game.pending && game.pending.userId === userId) game.pending = null;

    if (game.players.length === 1) {
      game.phase = 'finished';
      game.winnerIds = [game.players[0].id];
    } else if (game.players.length === 0) {
      game.phase = 'finished';
      game.winnerIds = [];
    } else {
      if (index < game.turnIndex) game.turnIndex -= 1;
      if (game.turnIndex >= game.players.length) game.turnIndex = 0;
    }

    game.updatedAt = now;
    return { ok: true, removed, gameEnded: game.phase === 'finished' };
  }

  function sortedPlayers(game) {
    return game.players.slice().sort((a, b) => b.score - a.score || a.name.localeCompare(b.name, 'zh-CN'));
  }

  function parseMode(input) {
    const value = String(input || '').trim().toLowerCase();
    if (!value || value === '轮流' || value === '輪流' || value === 'turn') return 'turn';
    if (value === '抢答' || value === '搶答' || value === 'rush') return 'rush';
    return null;
  }

  function parseTarget(input) {
    if (!input) return DEFAULT_TARGET;
    const value = Number.parseInt(String(input), 10);
    if (!Number.isInteger(value) || value < MIN_TARGET || value > MAX_TARGET) return null;
    return value;
  }

  function randomKeyword(randomFn = Math.random) {
    const candidates = POPULAR_KEYWORDS.filter((char) => (CORPUS_INDEX.keywordCounts.get(char) || 0) >= 8);
    const source = candidates.length ? candidates : POPULAR_KEYWORDS;
    return source[Math.floor(randomFn() * source.length)] || '月';
  }

  function exampleForKeyword(keyword, randomFn = Math.random) {
    const candidates = CORPUS_INDEX.lines.filter((entry) => entry.key.includes(keyword));
    if (!candidates.length) return null;
    return candidates[Math.floor(randomFn() * candidates.length)];
  }

  function safeKeyPart(value) {
    return encodeURIComponent(String(value || 'unknown')).slice(0, 180);
  }

  function gameStorageKey(groupId) {
    return `${STORAGE_PREFIX}${safeKeyPart(groupId)}`;
  }

  function isStale(game, now = Date.now()) {
    return !game || !Number.isFinite(game.updatedAt) || now - game.updatedAt > STALE_MS;
  }

  function isGameManager(ctx, game) {
    const userId = ctx && ctx.player ? String(ctx.player.userId || '') : '';
    const privilege = Number(ctx && ctx.privilegeLevel) || 0;
    return userId === String(game.hostId) || privilege >= 50;
  }

  function modeLabel(mode) {
    return mode === 'rush' ? '抢答令' : '轮流令';
  }

  function formatStandings(game) {
    return sortedPlayers(game)
      .map((player, index) => `${index + 1}. ${player.name}：${player.score}/${game.target}分`)
      .join('\n');
  }

  const HELP_TEXT = [
    '《澄清南北·飞花令》v0.1.0',
    '',
    '开席：',
    '.飞花令 开局 <令字|随机> [轮流|抢答] [目标分]',
    '.飞花令 加入',
    '.飞花令 退出　　　　仅开席前',
    '.飞花令 开始',
    '',
    '接令：',
    '.飞花令 接 <诗句>',
    '.飞花令 认输',
    '',
    '裁决与查询：',
    '.飞花令 认可　　　　认可当前未收录诗句',
    '.飞花令 驳回',
    '.飞花令 状态',
    '.飞花令 示例 [字]',
    '.飞花令 词库',
    '.飞花令 结束',
    '',
    '默认轮流令，先得5分者胜；目标分可设3至20。',
    '词库未收录的真实诗句不会直接判错，而由设席者或群管理裁决。',
  ].join('\n');

  function registerSealDice() {
    if (typeof seal === 'undefined' || !seal.ext) return;
    if (seal.ext.find(EXT_NAME)) return;

    const ext = seal.ext.new(EXT_NAME, '澄清南北', EXT_VERSION);

    function done() {
      return seal.ext.newCmdExecuteResult(true);
    }

    function reply(ctx, msg, text) {
      seal.replyToSender(ctx, msg, text);
      return done();
    }

    function identity(ctx) {
      return {
        userId: String(ctx && ctx.player ? ctx.player.userId || '' : ''),
        name: String(ctx && ctx.player ? ctx.player.name || '无名客' : '无名客'),
      };
    }

    function requireGroup(ctx, msg) {
      if (ctx && ctx.isPrivate) {
        reply(ctx, msg, '飞花令需要在群聊中设席。');
        return null;
      }
      const groupId = ctx && ctx.group ? String(ctx.group.groupId || '') : '';
      if (!groupId) {
        reply(ctx, msg, '无法识别当前群聊。');
        return null;
      }
      return groupId;
    }

    function loadGame(groupId) {
      const key = gameStorageKey(groupId);
      const raw = ext.storageGet(key);
      if (!raw) return null;
      try {
        const game = JSON.parse(raw);
        if (isStale(game)) {
          ext.storageSet(key, '');
          return null;
        }
        return game;
      } catch (_error) {
        ext.storageSet(key, '');
        return null;
      }
    }

    function saveGame(groupId, game) {
      ext.storageSet(gameStorageKey(groupId), JSON.stringify(game));
    }

    function clearGame(groupId) {
      ext.storageSet(gameStorageKey(groupId), '');
    }

    const cmd = seal.ext.newCmdItemInfo();
    cmd.name = '飞花令';
    cmd.help = HELP_TEXT;
    cmd.solve = (ctx, msg, cmdArgs) => {
      const action = String(cmdArgs.getArgN(1) || '').trim();

      if (!action || action === '帮助' || action === 'help') return reply(ctx, msg, HELP_TEXT);

      const who = identity(ctx);

      if (action === '词库' || action === '詞庫') {
        const popular = POPULAR_KEYWORDS
          .map((char) => `${char}${CORPUS_INDEX.keywordCounts.get(char) || 0}`)
          .join('、');
        return reply(
          ctx,
          msg,
          `精选词库版本：${CORPUS.corpusVersion}\n` +
          `作品记录：${CORPUS.records.length}\n` +
          `独立诗句：${CORPUS_INDEX.lines.length}\n` +
          `常用令字覆盖：${popular}\n\n` +
          '词库只用于快速自动核验；未收录诗句可由设席者人工认可。'
        );
      }

      if (action === '示例' || action === '例句') {
        const requested = String(cmdArgs.getArgN(2) || '').trim();
        const keyword = requested ? validateKeyword(requested) : randomKeyword();
        if (!keyword) return reply(ctx, msg, '示例令字必须是一个汉字。');
        const entry = exampleForKeyword(keyword);
        if (!entry) return reply(ctx, msg, `当前词库中没有找到含“${keyword}”的示例。`);
        return reply(
          ctx,
          msg,
          `令字“${keyword}”示例：\n${entry.line}\n——${entry.dynasty}·${entry.author}《${entry.title}》`
        );
      }

      const groupId = requireGroup(ctx, msg);
      if (!groupId) return done();

      let game = loadGame(groupId);

      if (action === '开局' || action === '開局') {
        if (game && (game.phase === 'lobby' || game.phase === 'playing')) {
          return reply(ctx, msg, '本群已有一席飞花令正在进行。');
        }

        const keywordInput = String(cmdArgs.getArgN(2) || '').trim();
        if (!keywordInput) {
          return reply(ctx, msg, '请指定令字，例如“.飞花令 开局 月”，或使用“随机”。');
        }
        const keyword =
          keywordInput === '随机' || keywordInput === '隨機'
            ? randomKeyword()
            : validateKeyword(keywordInput);
        if (!keyword) return reply(ctx, msg, '令字必须是一个汉字。');

        const mode = parseMode(String(cmdArgs.getArgN(3) || '').trim());
        if (!mode) return reply(ctx, msg, '模式只能是“轮流”或“抢答”。');

        const target = parseTarget(String(cmdArgs.getArgN(4) || '').trim());
        if (target === null) return reply(ctx, msg, `目标分必须是${MIN_TARGET}至${MAX_TARGET}之间的整数。`);

        game = createGame(who.userId, who.name, keyword, mode, target);
        saveGame(groupId, game);

        return reply(
          ctx,
          msg,
          `${who.name}设下飞花令之席。\n` +
          `令字：“${keyword}”\n模式：${modeLabel(mode)}\n目标：先得${target}分\n\n` +
          '设席者已自动入席，其余人发送“.飞花令 加入”；人齐后发送“.飞花令 开始”。'
        );
      }

      if (!game) return reply(ctx, msg, '本群当前没有飞花令。发送“.飞花令 开局 月”即可设席。');

      if (action === '加入') {
        const result = addPlayer(game, who.userId, who.name);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);
        return reply(ctx, msg, `${who.name}入席。当前：${game.players.map((p) => p.name).join('、')}`);
      }

      if (action === '退出' || action === '離席') {
        const result = removeLobbyPlayer(game, who.userId);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);
        return reply(ctx, msg, `${who.name}已离席。`);
      }

      if (action === '开始' || action === '開始') {
        if (!isGameManager(ctx, game)) return reply(ctx, msg, '只有设席者、群管理或骰主可以开席。');
        const result = startGame(game);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);

        const nextText =
          game.mode === 'turn'
            ? `首位应答者：${currentPlayer(game).name}`
            : '抢答已经开始，席中人皆可接令。';

        return reply(
          ctx,
          msg,
          `飞花令开席！\n令字：“${game.keyword}”\n模式：${modeLabel(game.mode)}\n${nextText}\n\n` +
          '使用“.飞花令 接 <诗句>”。'
        );
      }

      if (action === '接' || action === '答') {
        let textParts = [];
        for (let i = 2; i <= 30; i += 1) {
          const part = cmdArgs.getArgN(i);
          if (!part) break;
          textParts.push(part);
        }
        const answerText = textParts.join(' ').trim();
        const result = submitAnswer(game, who.userId, who.name, answerText);
        if (!result.ok) return reply(ctx, msg, result.error);

        saveGame(groupId, game);

        if (result.type === 'pending') {
          return reply(
            ctx,
            msg,
            `<${who.name}>接令：\n${result.inspected.display}\n\n` +
            '此句未在当前精选词库中检出，暂不判错。\n' +
            '请设席者或群管理发送“.飞花令 认可”或“.飞花令 驳回”。'
          );
        }

        const entry = result.inspected.entry;
        let text =
          `<${who.name}>接令：\n${result.inspected.display}\n\n` +
          `词库核验：${entry.dynasty}·${entry.author}《${entry.title}》\n` +
          `【接令成功】当前${result.player.score}/${game.target}分。`;

        if (result.gameEnded) {
          text += `\n\n${who.name}先得${game.target}分，本席胜负已定。`;
        } else if (game.mode === 'turn') {
          text += `\n下一位：${currentPlayer(game).name}`;
        }
        return reply(ctx, msg, text);
      }

      if (action === '认可' || action === '認可' || action === '驳回' || action === '駁回') {
        if (!isGameManager(ctx, game)) return reply(ctx, msg, '只有设席者、群管理或骰主可以裁决。');
        const approve = action === '认可' || action === '認可';
        const result = resolvePending(game, approve);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);

        if (approve) {
          let text =
            `设席者认可：\n${result.pending.display}\n\n` +
            `【接令成功】${result.player.name}当前${result.player.score}/${game.target}分。`;
          if (result.gameEnded) {
            text += `\n${result.player.name}先得${game.target}分，本席胜负已定。`;
          } else if (game.mode === 'turn') {
            text += `\n下一位：${currentPlayer(game).name}`;
          }
          return reply(ctx, msg, text);
        }

        let text = `设席者驳回：\n${result.pending.display}\n\n【本次不得分】`;
        if (game.mode === 'turn' && game.phase === 'playing') {
          text += `\n下一位：${currentPlayer(game).name}`;
        }
        return reply(ctx, msg, text);
      }

      if (action === '认输' || action === '認輸') {
        const result = concede(game, who.userId);
        if (!result.ok) return reply(ctx, msg, result.error);
        saveGame(groupId, game);

        if (result.gameEnded && game.players.length === 1) {
          return reply(ctx, msg, `${who.name}离席认输。\n胜者：${game.players[0].name}`);
        }
        return reply(ctx, msg, `${who.name}离席认输。席中尚有：${game.players.map((p) => p.name).join('、')}`);
      }

      if (action === '状态' || action === '狀態') {
        const pendingText = game.pending
          ? `\n待裁决：${game.pending.name}——${game.pending.display}`
          : '';
        const turnText =
          game.phase === 'playing' && game.mode === 'turn'
            ? `\n当前应答：${currentPlayer(game).name}`
            : '';
        const winnerText =
          game.phase === 'finished' && game.winnerIds.length
            ? `\n胜者：${game.players.filter((p) => game.winnerIds.includes(p.id)).map((p) => p.name).join('、')}`
            : '';

        return reply(
          ctx,
          msg,
          `飞花令状态：${game.phase}\n令字：“${game.keyword}”\n模式：${modeLabel(game.mode)}\n` +
          `${formatStandings(game)}${turnText}${pendingText}${winnerText}\n` +
          `已用诗句：${game.usedDisplay.length}条`
        );
      }

      if (action === '结束' || action === '結束') {
        if (!isGameManager(ctx, game)) return reply(ctx, msg, '只有设席者、群管理或骰主可以收席。');
        clearGame(groupId);
        return reply(ctx, msg, `${who.name}命人撤去酒筹，本席飞花令结束。`);
      }

      return reply(ctx, msg, `未知操作：“${action}”。\n\n${HELP_TEXT}`);
    };

    ext.cmdMap['飞花令'] = cmd;
    ext.cmdMap['飛花令'] = cmd;
    ext.cmdMap['feihua'] = cmd;

    seal.ext.register(ext);
  }

  const testApi = {
    CORPUS,
    POPULAR_KEYWORDS,
    normalizeText,
    splitCandidate,
    buildCorpusIndex,
    validateKeyword,
    candidateKeys,
    inspectCandidate,
    createGame,
    addPlayer,
    startGame,
    currentPlayer,
    submitAnswer,
    resolvePending,
    concede,
    sortedPlayers,
    parseMode,
    parseTarget,
    exampleForKeyword,
    isStale,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = testApi;
  }

  registerSealDice();
})();
