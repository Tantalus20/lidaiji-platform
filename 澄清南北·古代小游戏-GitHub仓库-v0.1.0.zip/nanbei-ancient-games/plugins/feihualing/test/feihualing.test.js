const test = require('node:test');
const assert = require('node:assert/strict');

const api = require('../dist/nanbei-feihualing.js');

test('精选词库达到可用规模并包含多朝代', () => {
  assert.ok(api.CORPUS.records.length >= 120);
  const lines = api.CORPUS.records.flatMap((record) => record.lines);
  assert.ok(lines.length >= 450);
  const dynasties = new Set(api.CORPUS.records.map((record) => record.dynasty));
  assert.ok(dynasties.has('唐'));
  assert.ok(dynasties.has('宋'));
  assert.ok(dynasties.has('北朝'));
  assert.ok(dynasties.has('南朝'));
});

test('繁简、标点与空格归一化', () => {
  assert.equal(api.normalizeText('春風 又 綠 江南岸。'), '春风又绿江南岸');
  assert.equal(api.normalizeText('明月何時照我還'), '明月何时照我还');
});

test('已收录诗句自动核验并返回出处', () => {
  const result = api.inspectCandidate('月', '海上生明月，天涯共此时', []);
  assert.equal(result.ok, true);
  assert.equal(result.type, 'known');
  assert.equal(result.entry.author, '张九龄');
  assert.equal(result.entry.title, '望月怀远');
});

test('没有令字、过短与重复均被拒绝', () => {
  assert.equal(api.inspectCandidate('月', '春风又绿江南岸', []).ok, false);
  assert.equal(api.inspectCandidate('月', '明月', []).ok, false);
  const known = api.inspectCandidate('月', '举头望明月', []);
  assert.equal(known.ok, true);
  const duplicate = api.inspectCandidate('月', '举头望明月', known.keys);
  assert.equal(duplicate.type, 'duplicate');
});

test('未收录但格式合格的诗句进入人工裁决', () => {
  const result = api.inspectCandidate('月', '某家新作月照虚庭人未归', []);
  assert.equal(result.ok, true);
  assert.equal(result.type, 'pending');
});

test('轮流令严格限制当前答者并推进回合', () => {
  const game = api.createGame('u1', '甲', '月', 'turn', 3, 1000);
  api.addPlayer(game, 'u2', '乙', 1001);
  api.startGame(game, 1002);

  const wrongTurn = api.submitAnswer(game, 'u2', '乙', '海上生明月', 1003);
  assert.equal(wrongTurn.ok, false);

  const accepted = api.submitAnswer(game, 'u1', '甲', '海上生明月', 1004);
  assert.equal(accepted.ok, true);
  assert.equal(accepted.type, 'known');
  assert.equal(game.players[0].score, 1);
  assert.equal(api.currentPlayer(game).id, 'u2');
});

test('人工认可给分，驳回在轮流令中跳到下一位', () => {
  const game = api.createGame('u1', '甲', '月', 'turn', 3, 1000);
  api.addPlayer(game, 'u2', '乙', 1001);
  api.startGame(game, 1002);

  let pending = api.submitAnswer(game, 'u1', '甲', '新月照庭阶人影未曾来', 1003);
  assert.equal(pending.type, 'pending');
  let approved = api.resolvePending(game, true, 1004);
  assert.equal(approved.ok, true);
  assert.equal(game.players[0].score, 1);
  assert.equal(api.currentPlayer(game).id, 'u2');

  pending = api.submitAnswer(game, 'u2', '乙', '月下新声落满台', 1005);
  assert.equal(pending.type, 'pending');
  const rejected = api.resolvePending(game, false, 1006);
  assert.equal(rejected.ok, true);
  assert.equal(game.players[1].score, 0);
  assert.equal(api.currentPlayer(game).id, 'u1');
});

test('抢答令允许任意席中玩家先答，达到目标结束', () => {
  const game = api.createGame('u1', '甲', '月', 'rush', 3, 1000);
  api.addPlayer(game, 'u2', '乙', 1001);
  api.startGame(game, 1002);

  const answers = ['海上生明月', '举头望明月', '月是故乡明'];
  for (let i = 0; i < answers.length; i += 1) {
    const result = api.submitAnswer(game, 'u2', '乙', answers[i], 1003 + i);
    assert.equal(result.ok, true);
  }
  assert.equal(game.phase, 'finished');
  assert.deepEqual(game.winnerIds, ['u2']);
});

test('认输后仅剩一人则自动结束', () => {
  const game = api.createGame('u1', '甲', '花', 'turn', 5, 1000);
  api.addPlayer(game, 'u2', '乙', 1001);
  api.startGame(game, 1002);
  const result = api.concede(game, 'u2', 1003);
  assert.equal(result.gameEnded, true);
  assert.equal(game.phase, 'finished');
  assert.deepEqual(game.winnerIds, ['u1']);
});

test('参数与过期边界', () => {
  assert.equal(api.validateKeyword('月'), '月');
  assert.equal(api.validateKeyword('明月'), null);
  assert.equal(api.parseMode('轮流'), 'turn');
  assert.equal(api.parseMode('抢答'), 'rush');
  assert.equal(api.parseMode('未知'), null);
  assert.equal(api.parseTarget('3'), 3);
  assert.equal(api.parseTarget('20'), 20);
  assert.equal(api.parseTarget('2'), null);
  assert.equal(api.parseTarget('21'), null);

  const game = api.createGame('u1', '甲', '月', 'turn', 5, 1000);
  game.updatedAt = 1000;
  assert.equal(api.isStale(game, 1000 + 23 * 60 * 60 * 1000), false);
  assert.equal(api.isStale(game, 1000 + 25 * 60 * 60 * 1000), true);
});
