// ==UserScript==
// @name         澄清南北·投壶
// @author       澄清南北
// @version      0.1.0
// @description  四矢投壶、花式投法与群聊多人立马赛。仅供娱乐。
// @timestamp    1785699720
// @license      0BSD
// ==/UserScript==

(function () {
  'use strict';

  const EXT_NAME = 'nanbei-touhu';
  const EXT_VERSION = '0.1.0';
  const STORAGE_PREFIX = 'touhu-game-v1:';

  const DEFAULT_ROUNDS = 3;
  const MIN_ROUNDS = 1;
  const MAX_ROUNDS = 9;
  const MAX_PLAYERS = 12;
  const ARROWS_PER_TURN = 4;
  const STALE_MS = 24 * 60 * 60 * 1000;
  const QUICK_COOLDOWN_MS = 3000;

  /**
   * 投法名称来自历史投壶及后世花式名称。
   * 命中率和筹数是为群聊竞技设计的现代平衡参数，不声称为古代定制。
   */
  const TECHNIQUES = Object.freeze({
    正投: Object.freeze({
      key: '正投',
      label: '正投',
      chance: 0.68,
      points: 1,
      hitText: '顺投入壶',
      description: '最稳妥的投法。命中率高，每中一矢得1筹。',
    }),
    依耳: Object.freeze({
      key: '依耳',
      label: '依耳',
      chance: 0.50,
      points: 2,
      hitText: '倚耳而入',
      description: '取壶耳一侧而投。难度适中，每中一矢得2筹。',
    }),
    贯耳: Object.freeze({
      key: '贯耳',
      label: '贯耳',
      chance: 0.34,
      points: 3,
      hitText: '贯耳而过',
      description: '令矢穿过壶耳。难度较高，每中一矢得3筹。',
    }),
    背投: Object.freeze({
      key: '背投',
      label: '背投',
      chance: 0.22,
      points: 5,
      hitText: '背身投中',
      description: '背向壶器而投。风险最高，每中一矢得5筹。',
    }),
  });

  const TECHNIQUE_ALIASES = Object.freeze({
    正投: '正投',
    正: '正投',
    顺投: '正投',
    順投: '正投',
    standard: '正投',

    依耳: '依耳',
    倚耳: '依耳',
    依: '依耳',

    贯耳: '贯耳',
    貫耳: '贯耳',
    贯: '贯耳',
    貫: '贯耳',

    背投: '背投',
    倒投: '背投',
    背: '背投',
    back: '背投',
  });

  const FAILURE_TEXTS = Object.freeze([
    '触壶而落',
    '越壶而过',
    '矢短未及',
    '倚竿，不释算',
    '偏出壶侧',
    '落于席前',
  ]);

  const TURN_COMMENTS = Object.freeze({
    perfect: [
      '四矢皆入，宾主尽欢。',
      '全壶既成，席间无不称善。',
      '始终俱中，可为今日之冠。',
    ],
    excellent: [
      '三矢得中，技近纯熟。',
      '连中三矢，足以立马。',
      '壶前举止从容，所得甚厚。',
    ],
    good: [
      '二矢得中，进退有度。',
      '得失相半，尚称稳健。',
      '两中两失，胜负仍看后局。',
    ],
    slight: [
      '仅得一中，聊存其礼。',
      '一矢入壶，尚未空手而归。',
      '虽只一中，后局仍可再图。',
    ],
    miss: [
      '四矢俱失，宜整衣冠而再试。',
      '本投未入，史官据实而书。',
      '壶在席前，而矢各有远志。',
    ],
  });

  const quickCooldowns = new Map();

  function safeRandom(randomFn) {
    const value = Number(randomFn());
    if (!Number.isFinite(value)) return Math.random();
    if (value <= 0) return 0;
    if (value >= 1) return 0.999999999999;
    return value;
  }

  function pick(items, randomFn = Math.random) {
    if (!Array.isArray(items) || items.length === 0) return '';
    const index = Math.floor(safeRandom(randomFn) * items.length);
    return items[index];
  }

  function parseTechnique(input) {
    const normalized = String(input || '').trim();
    if (!normalized) return TECHNIQUES.正投;
    const key = TECHNIQUE_ALIASES[normalized];
    return key ? TECHNIQUES[key] : null;
  }

  function longestHitStreak(arrows) {
    let longest = 0;
    let current = 0;
    for (const arrow of arrows) {
      if (arrow.hit) {
        current += 1;
        if (current > longest) longest = current;
      } else {
        current = 0;
      }
    }
    return longest;
  }

  function calculateBonuses(arrows) {
    if (!Array.isArray(arrows) || arrows.length !== ARROWS_PER_TURN) {
      throw new Error(`每投必须恰有${ARROWS_PER_TURN}矢`);
    }

    const bonuses = [];
    let bonusScore = 0;

    if (arrows[0].hit) {
      bonuses.push({ name: '有初', score: 1, description: '第一矢入壶' });
      bonusScore += 1;
    }

    if (arrows[ARROWS_PER_TURN - 1].hit) {
      bonuses.push({ name: '有终', score: 1, description: '第四矢入壶' });
      bonusScore += 1;
    }

    if (arrows.every((arrow) => arrow.hit)) {
      bonuses.push({ name: '全壶', score: 3, description: '四矢皆入' });
      bonusScore += 3;
    }

    const streak = longestHitStreak(arrows);
    if (streak >= 3) {
      bonuses.push({ name: '连中', score: 1, description: `连续${streak}矢入壶` });
      bonusScore += 1;
    }

    return { bonuses, bonusScore, longestStreak: streak };
  }

  function throwArrows(techniqueInput = '正投', randomFn = Math.random) {
    const technique = typeof techniqueInput === 'string'
      ? parseTechnique(techniqueInput)
      : techniqueInput;

    if (!technique || !TECHNIQUES[technique.key]) {
      throw new Error('未知投法');
    }

    const arrows = [];
    for (let index = 0; index < ARROWS_PER_TURN; index += 1) {
      const roll = safeRandom(randomFn);
      arrows.push({
        index: index + 1,
        roll,
        hit: roll < technique.chance,
      });
    }

    const hits = arrows.filter((arrow) => arrow.hit).length;
    const baseScore = hits * technique.points;
    const bonusResult = calculateBonuses(arrows);

    return {
      technique: technique.key,
      chance: technique.chance,
      pointsPerHit: technique.points,
      arrows,
      hits,
      baseScore,
      bonuses: bonusResult.bonuses,
      bonusScore: bonusResult.bonusScore,
      longestStreak: bonusResult.longestStreak,
      totalScore: baseScore + bonusResult.bonusScore,
    };
  }

  function turnComment(result, randomFn = Math.random) {
    if (result.hits === 4) return pick(TURN_COMMENTS.perfect, randomFn);
    if (result.hits === 3) return pick(TURN_COMMENTS.excellent, randomFn);
    if (result.hits === 2) return pick(TURN_COMMENTS.good, randomFn);
    if (result.hits === 1) return pick(TURN_COMMENTS.slight, randomFn);
    return pick(TURN_COMMENTS.miss, randomFn);
  }

  function formatArrow(arrow, technique, randomFn = Math.random) {
    const ordinal = ['第一矢', '第二矢', '第三矢', '第四矢'][arrow.index - 1];
    if (arrow.hit) {
      return `${ordinal}：【中】${technique.hitText}`;
    }
    return `${ordinal}：【失】${pick(FAILURE_TEXTS, randomFn)}`;
  }

  function formatTurn(result, randomFn = Math.random) {
    const technique = TECHNIQUES[result.technique];
    const arrowLines = result.arrows
      .map((arrow) => formatArrow(arrow, technique, randomFn))
      .join('\n');

    const bonusText = result.bonuses.length
      ? result.bonuses.map((bonus) => `${bonus.name}+${bonus.score}`).join('、')
      : '无';

    return [
      `投法：${technique.label}`,
      arrowLines,
      '',
      `本投：${result.hits}/${ARROWS_PER_TURN}矢入壶`,
      `基本得筹：${result.baseScore}`,
      `加彩：${bonusText}`,
      `合计：${result.totalScore}筹`,
      `史臣曰：${turnComment(result, randomFn)}`,
    ].join('\n');
  }

  function createGame(hostId, hostName, rounds = DEFAULT_ROUNDS, now = Date.now()) {
    return {
      schemaVersion: 1,
      phase: 'lobby',
      hostId,
      hostName,
      rounds,
      currentRound: 1,
      players: [
        {
          id: hostId,
          name: hostName,
          horses: 0,
          totalScore: 0,
          roundResults: [],
          rolled: false,
        },
      ],
      createdAt: now,
      updatedAt: now,
    };
  }

  function addPlayer(game, userId, name, now = Date.now()) {
    if (game.phase !== 'lobby') {
      return { ok: false, error: '投壶已经开始，不能中途入席。' };
    }

    const existing = game.players.find((player) => player.id === userId);
    if (existing) {
      existing.name = name;
      game.updatedAt = now;
      return { ok: false, error: '你已经在投壶席中。' };
    }

    if (game.players.length >= MAX_PLAYERS) {
      return { ok: false, error: `本局最多允许${MAX_PLAYERS}人。` };
    }

    game.players.push({
      id: userId,
      name,
      horses: 0,
      totalScore: 0,
      roundResults: [],
      rolled: false,
    });
    game.updatedAt = now;
    return { ok: true };
  }

  function removePlayer(game, userId, now = Date.now()) {
    if (game.phase !== 'lobby') {
      return { ok: false, error: '投壶已经开始，不能中途离席。' };
    }

    if (userId === game.hostId) {
      return { ok: false, error: '设席者不能直接退出，请使用“.投壶 结束”。' };
    }

    const index = game.players.findIndex((player) => player.id === userId);
    if (index < 0) return { ok: false, error: '你尚未加入本局。' };

    game.players.splice(index, 1);
    game.updatedAt = now;
    return { ok: true };
  }

  function startGame(game, now = Date.now()) {
    if (game.phase !== 'lobby') return { ok: false, error: '本局已经开始。' };
    if (game.players.length < 2) return { ok: false, error: '至少需要两人入席。' };

    game.phase = 'playing';
    game.currentRound = 1;
    for (const player of game.players) player.rolled = false;
    game.updatedAt = now;
    return { ok: true };
  }

  function awardRoundHorses(game) {
    const scores = game.players.map((player) => {
      const latest = player.roundResults[player.roundResults.length - 1];
      return latest ? latest.totalScore : 0;
    });
    const highest = Math.max(...scores);

    const recipients = [];
    for (const player of game.players) {
      const latest = player.roundResults[player.roundResults.length - 1];
      if (latest && latest.totalScore === highest) {
        player.horses += 1;
        recipients.push(player);
      }
    }

    return { highest, recipients };
  }

  function applyTurn(
    game,
    userId,
    name,
    techniqueInput = '正投',
    randomFn = Math.random,
    now = Date.now()
  ) {
    if (game.phase !== 'playing') {
      return { ok: false, error: '当前没有正在进行的投壶对局。' };
    }

    const player = game.players.find((item) => item.id === userId);
    if (!player) return { ok: false, error: '你不在本局席中。' };
    if (player.rolled) {
      return { ok: false, error: `你在第${game.currentRound}轮已经投过四矢。` };
    }

    const technique = parseTechnique(techniqueInput);
    if (!technique) {
      return {
        ok: false,
        error: '未知投法。可选：正投、依耳、贯耳、背投。',
      };
    }

    player.name = name;
    const result = throwArrows(technique, randomFn);
    result.round = game.currentRound;
    player.roundResults.push(result);
    player.totalScore += result.totalScore;
    player.rolled = true;
    game.updatedAt = now;

    let roundEnded = false;
    let gameEnded = false;
    let horseResult = null;
    const completedRound = game.currentRound;

    if (game.players.every((item) => item.rolled)) {
      roundEnded = true;
      horseResult = awardRoundHorses(game);

      if (game.currentRound >= game.rounds) {
        game.phase = 'finished';
        gameEnded = true;
      } else {
        game.currentRound += 1;
        for (const item of game.players) item.rolled = false;
      }
    }

    return {
      ok: true,
      player,
      result,
      roundEnded,
      gameEnded,
      horseResult,
      completedRound,
    };
  }

  function sortedPlayers(game) {
    return game.players.slice().sort((a, b) => {
      if (b.horses !== a.horses) return b.horses - a.horses;
      if (b.totalScore !== a.totalScore) return b.totalScore - a.totalScore;
      return a.name.localeCompare(b.name, 'zh-CN');
    });
  }

  function winners(game) {
    if (!game.players.length) return [];
    const sorted = sortedPlayers(game);
    const best = sorted[0];
    return sorted.filter(
      (player) =>
        player.horses === best.horses &&
        player.totalScore === best.totalScore
    );
  }

  function formatStandings(game) {
    return sortedPlayers(game)
      .map((player, index) => {
        const latest = player.roundResults[player.roundResults.length - 1];
        const latestText = latest ? `末轮${latest.totalScore}筹` : '尚未投';
        const status =
          game.phase === 'playing'
            ? player.rolled
              ? '已投'
              : '待投'
            : '';
        return (
          `${index + 1}. ${player.name}：${player.horses}马，` +
          `${player.totalScore}筹（${latestText}${status ? `，${status}` : ''}）`
        );
      })
      .join('\n');
  }

  function formatHorseResult(horseResult) {
    if (!horseResult || !horseResult.recipients.length) return '';
    const names = horseResult.recipients.map((player) => player.name).join('、');
    if (horseResult.recipients.length === 1) {
      return `${names}以${horseResult.highest}筹居首，立一马。`;
    }
    return `${names}同以${horseResult.highest}筹居首，各立一马。`;
  }

  function parseRounds(text) {
    if (!text) return DEFAULT_ROUNDS;
    const value = Number.parseInt(text, 10);
    if (!Number.isInteger(value) || value < MIN_ROUNDS || value > MAX_ROUNDS) {
      return null;
    }
    return value;
  }

  function safeKeyPart(value) {
    return encodeURIComponent(String(value || 'unknown')).slice(0, 180);
  }

  function gameStorageKey(groupId) {
    return `${STORAGE_PREFIX}${safeKeyPart(groupId)}`;
  }

  function isStale(game, now = Date.now()) {
    return !game || !Number.isFinite(game.updatedAt) || now - game.updatedAt > STALE_MS;
  }

  function isGameManager(ctx, game) {
    const userId = ctx && ctx.player ? String(ctx.player.userId || '') : '';
    const privilege = Number(ctx && ctx.privilegeLevel) || 0;
    return userId === String(game.hostId) || privilege >= 50;
  }

  const HELP_TEXT = [
    '《澄清南北·投壶》v0.1.0',
    '',
    '随手投四矢：',
    '.投壶　　　　　　默认正投',
    '.投壶 正投',
    '.投壶 依耳',
    '.投壶 贯耳',
    '.投壶 背投',
    '',
    '多人立马赛：',
    '.投壶 开局 [轮数]　默认3轮，设席者自动入席',
    '.投壶 加入',
    '.投壶 退出　　　　仅开局前',
    '.投壶 开始　　　　设席者或群管理执行',
    '.投壶 投 [投法]　　默认正投',
    '.投壶 状态',
    '.投壶 结束　　　　设席者或群管理执行',
    '.投壶 投法',
    '.投壶 规则',
    '',
    '每轮最高者立一马；最终先比马数，再比总筹。',
    '只记娱乐筹数，不连接游戏经济点或玩家资源。',
  ].join('\n');

  const TECHNIQUE_TEXT = [
    '【投法】',
    '正投：命中率68%，每中1筹。',
    '依耳：命中率50%，每中2筹。',
    '贯耳：命中率34%，每中3筹。',
    '背投：命中率22%，每中5筹。',
    '',
    '加彩：',
    '有初：第一矢入壶，+1筹。',
    '有终：第四矢入壶，+1筹。',
    '全壶：四矢皆入，+3筹。',
    '连中：连续至少三矢入壶，+1筹。',
    '',
    '投法名称取自投壶及后世花式；',
    '命中率、筹数和加彩均为现代群聊平衡规则。',
  ].join('\n');

  const RULES_TEXT = [
    '【投壶之礼】',
    '投壶源出宴饮礼仪，以矢投壶，顺投入壶者释算。',
    '本插件每次投四矢，并保留“有初”“有终”“立马”等称谓。',
    '',
    '【多人立马赛】',
    '默认三轮。每人每轮选择一种投法，投四矢。',
    '该轮总筹最高者立一马；同分者各立一马。',
    '全部轮次结束后，先比较马数，再比较累计筹数；仍同则并列。',
    '',
    '【简化说明】',
    '古代投壶礼制、鼓节、罚爵和历代花式十分复杂。',
    '本插件以史料称谓为骨架，采用现代概率与计分，',
    '不声称复原某一朝代的完整投壶制度。',
  ].join('\n');

  function registerSealDice() {
    if (typeof seal === 'undefined' || !seal.ext) return;
    if (seal.ext.find(EXT_NAME)) return;

    const ext = seal.ext.new(EXT_NAME, '澄清南北', EXT_VERSION);

    function resultDone() {
      return seal.ext.newCmdExecuteResult(true);
    }

    function reply(ctx, msg, text) {
      seal.replyToSender(ctx, msg, text);
      return resultDone();
    }

    function getIdentity(ctx) {
      return {
        userId: String(ctx && ctx.player ? ctx.player.userId || '' : ''),
        name: String(ctx && ctx.player ? ctx.player.name || '无名客' : '无名客'),
      };
    }

    function requireGroup(ctx, msg) {
      if (ctx && ctx.isPrivate) {
        reply(ctx, msg, '多人投壶只能在群聊中进行；私聊可以直接使用“.投壶”。');
        return null;
      }
      const groupId = ctx && ctx.group ? String(ctx.group.groupId || '') : '';
      if (!groupId) {
        reply(ctx, msg, '无法识别当前群聊，未建立投壶对局。');
        return null;
      }
      return groupId;
    }

    function loadGame(groupId) {
      const key = gameStorageKey(groupId);
      const raw = ext.storageGet(key);
      if (!raw) return null;

      try {
        const game = JSON.parse(raw);
        if (isStale(game)) {
          ext.storageSet(key, '');
          return null;
        }
        return game;
      } catch (_error) {
        ext.storageSet(key, '');
        return null;
      }
    }

    function saveGame(groupId, game) {
      ext.storageSet(gameStorageKey(groupId), JSON.stringify(game));
    }

    function clearGame(groupId) {
      ext.storageSet(gameStorageKey(groupId), '');
    }

    function quickThrow(ctx, msg, techniqueInput) {
      const identity = getIdentity(ctx);
      const technique = parseTechnique(techniqueInput);

      if (!technique) {
        return reply(ctx, msg, '未知投法。可选：正投、依耳、贯耳、背投。');
      }

      const scope =
        ctx && ctx.isPrivate
          ? `private:${identity.userId}`
          : `group:${ctx && ctx.group ? ctx.group.groupId : 'unknown'}:${identity.userId}`;

      const now = Date.now();
      const previous = quickCooldowns.get(scope) || 0;
      if (now - previous < QUICK_COOLDOWN_MS) {
        return reply(ctx, msg, '四矢尚未收回，请稍候片刻再投。');
      }
      quickCooldowns.set(scope, now);

      const result = throwArrows(technique);
      return reply(
        ctx,
        msg,
        `<${identity.name}>执四矢，立于席前——\n\n${formatTurn(result)}\n\n随机结果仅供娱乐。`
      );
    }

    const cmdTouhu = seal.ext.newCmdItemInfo();
    cmdTouhu.name = '投壶';
    cmdTouhu.help = HELP_TEXT;
    cmdTouhu.solve = (ctx, msg, cmdArgs) => {
      const action = String(cmdArgs.getArgN(1) || '').trim();

      if (!action) return quickThrow(ctx, msg, '正投');
      if (parseTechnique(action)) return quickThrow(ctx, msg, action);

      if (action === 'help' || action === '帮助') {
        return reply(ctx, msg, HELP_TEXT);
      }
      if (action === '规则') {
        return reply(ctx, msg, RULES_TEXT);
      }
      if (action === '投法' || action === '花式') {
        return reply(ctx, msg, TECHNIQUE_TEXT);
      }

      const groupId = requireGroup(ctx, msg);
      if (!groupId) return resultDone();

      const identity = getIdentity(ctx);
      let game = loadGame(groupId);

      if (action === '开局') {
        if (game && (game.phase === 'lobby' || game.phase === 'playing')) {
          return reply(ctx, msg, '本群已有一局投壶正在进行，请先结束旧局。');
        }

        const rounds = parseRounds(String(cmdArgs.getArgN(2) || '').trim());
        if (rounds === null) {
          return reply(ctx, msg, `轮数只能是${MIN_ROUNDS}至${MAX_ROUNDS}之间的整数。`);
        }

        game = createGame(identity.userId, identity.name, rounds);
        saveGame(groupId, game);

        return reply(
          ctx,
          msg,
          `${identity.name}陈壶设席，自己已先入席。\n` +
          `本局共${rounds}轮，最多${MAX_PLAYERS}人。\n` +
          '其余人请发送“.投壶 加入”；人齐后由设席者发送“.投壶 开始”。'
        );
      }

      if (!game) {
        return reply(ctx, msg, '本群当前没有多人投壶对局。发送“.投壶 开局”即可设席。');
      }

      if (action === '加入') {
        const joined = addPlayer(game, identity.userId, identity.name);
        if (!joined.ok) return reply(ctx, msg, joined.error);

        saveGame(groupId, game);
        return reply(
          ctx,
          msg,
          `${identity.name}入席。当前共${game.players.length}人：\n` +
          game.players.map((player) => `· ${player.name}`).join('\n')
        );
      }

      if (action === '退出') {
        const removed = removePlayer(game, identity.userId);
        if (!removed.ok) return reply(ctx, msg, removed.error);

        saveGame(groupId, game);
        return reply(ctx, msg, `${identity.name}离席。当前尚有${game.players.length}人。`);
      }

      if (action === '开始') {
        if (!isGameManager(ctx, game)) {
          return reply(ctx, msg, '只有设席者、群管理或骰主可以宣布开始。');
        }

        const started = startGame(game);
        if (!started.ok) return reply(ctx, msg, started.error);

        saveGame(groupId, game);
        return reply(
          ctx,
          msg,
          `投壶开席，共${game.rounds}轮。\n` +
          `入席者：${game.players.map((player) => player.name).join('、')}\n\n` +
          '第一轮开始。发送“.投壶 投 正投／依耳／贯耳／背投”。'
        );
      }

      if (action === '投') {
        const techniqueInput = String(cmdArgs.getArgN(2) || '正投').trim();
        const applied = applyTurn(
          game,
          identity.userId,
          identity.name,
          techniqueInput
        );

        if (!applied.ok) return reply(ctx, msg, applied.error);

        let text =
          `<${identity.name}>执四矢而投——\n\n${formatTurn(applied.result)}\n\n` +
          `累计：${applied.player.horses}马，${applied.player.totalScore}筹。`;

        if (applied.gameEnded) {
          const victors = winners(game);
          text +=
            `\n\n${applied.completedRound}轮既毕，投壶收席。\n` +
            `${formatHorseResult(applied.horseResult)}\n\n` +
            `${formatStandings(game)}\n\n` +
            `胜者：${victors.map((player) => player.name).join('、')}` +
            `（${victors[0].horses}马，${victors[0].totalScore}筹）`;
        } else if (applied.roundEnded) {
          text +=
            `\n\n第${applied.completedRound}轮结束。\n` +
            `${formatHorseResult(applied.horseResult)}\n\n` +
            `${formatStandings(game)}\n\n` +
            `第${game.currentRound}轮开始，请各自再次投壶。`;
        } else {
          const waiting = game.players
            .filter((player) => !player.rolled)
            .map((player) => player.name);
          text += `\n\n本轮待投：${waiting.join('、')}`;
        }

        saveGame(groupId, game);
        return reply(ctx, msg, text);
      }

      if (action === '状态') {
        if (game.phase === 'lobby') {
          return reply(
            ctx,
            msg,
            `投壶尚未开席：${game.players.length}/${MAX_PLAYERS}人，计划${game.rounds}轮。\n` +
            `设席者：${game.hostName}\n` +
            game.players.map((player) => `· ${player.name}`).join('\n')
          );
        }

        if (game.phase === 'finished') {
          const victors = winners(game);
          return reply(
            ctx,
            msg,
            `本局已经结束。\n${formatStandings(game)}\n\n` +
            `胜者：${victors.map((player) => player.name).join('、')}` +
            `（${victors[0].horses}马，${victors[0].totalScore}筹）`
          );
        }

        return reply(
          ctx,
          msg,
          `投壶进行中：第${game.currentRound}/${game.rounds}轮。\n${formatStandings(game)}`
        );
      }

      if (action === '结束') {
        if (!isGameManager(ctx, game)) {
          return reply(ctx, msg, '只有设席者、群管理或骰主可以撤壶收席。');
        }

        clearGame(groupId);
        return reply(ctx, msg, `${identity.name}命人撤壶收矢，本局投壶已经结束。`);
      }

      return reply(ctx, msg, `未知操作：“${action}”。\n\n${HELP_TEXT}`);
    };

    ext.cmdMap['投壶'] = cmdTouhu;
    ext.cmdMap['投壺'] = cmdTouhu;
    ext.cmdMap['touhu'] = cmdTouhu;

    seal.ext.register(ext);
  }

  const testApi = {
    TECHNIQUES,
    parseTechnique,
    longestHitStreak,
    calculateBonuses,
    throwArrows,
    createGame,
    addPlayer,
    removePlayer,
    startGame,
    awardRoundHorses,
    applyTurn,
    sortedPlayers,
    winners,
    parseRounds,
    isStale,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = testApi;
  }

  registerSealDice();
})();
