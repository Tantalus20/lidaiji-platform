const test = require('node:test');
const assert = require('node:assert/strict');

const {
  TECHNIQUES,
  parseTechnique,
  longestHitStreak,
  calculateBonuses,
  throwArrows,
  createGame,
  addPlayer,
  startGame,
  applyTurn,
  winners,
  parseRounds,
  isStale,
} = require('../nanbei-touhu.js');

function sequenceRandom(values) {
  let index = 0;
  return () => {
    if (index >= values.length) throw new Error('随机序列已耗尽');
    return values[index++];
  };
}

test('四种投法及常用别名能够解析', () => {
  assert.equal(parseTechnique('').key, '正投');
  assert.equal(parseTechnique('顺投').key, '正投');
  assert.equal(parseTechnique('倚耳').key, '依耳');
  assert.equal(parseTechnique('貫耳').key, '贯耳');
  assert.equal(parseTechnique('倒投').key, '背投');
  assert.equal(parseTechnique('不存在'), null);
});

test('投法概率与筹数保持公开规则值', () => {
  assert.deepEqual(
    Object.fromEntries(
      Object.entries(TECHNIQUES).map(([key, value]) => [
        key,
        [value.chance, value.points],
      ])
    ),
    {
      正投: [0.68, 1],
      依耳: [0.5, 2],
      贯耳: [0.34, 3],
      背投: [0.22, 5],
    }
  );
});

test('四矢皆中触发有初、有终、全壶和连中', () => {
  const result = throwArrows('正投', sequenceRandom([0.1, 0.1, 0.1, 0.1]));
  assert.equal(result.hits, 4);
  assert.equal(result.baseScore, 4);
  assert.equal(result.bonusScore, 6);
  assert.equal(result.totalScore, 10);
  assert.deepEqual(
    result.bonuses.map((bonus) => bonus.name),
    ['有初', '有终', '全壶', '连中']
  );
});

test('四矢俱失不得筹', () => {
  const result = throwArrows('正投', sequenceRandom([0.9, 0.9, 0.9, 0.9]));
  assert.equal(result.hits, 0);
  assert.equal(result.baseScore, 0);
  assert.equal(result.bonusScore, 0);
  assert.equal(result.totalScore, 0);
  assert.deepEqual(result.bonuses, []);
});

test('首尾命中但不连中时只计算有初与有终', () => {
  const result = throwArrows('依耳', sequenceRandom([0.1, 0.9, 0.9, 0.1]));
  assert.equal(result.hits, 2);
  assert.equal(result.baseScore, 4);
  assert.equal(result.bonusScore, 2);
  assert.equal(result.totalScore, 6);
  assert.deepEqual(
    result.bonuses.map((bonus) => bonus.name),
    ['有初', '有终']
  );
});

test('最长连中计算正确', () => {
  assert.equal(
    longestHitStreak([
      { hit: true },
      { hit: true },
      { hit: false },
      { hit: true },
    ]),
    2
  );
  assert.equal(
    longestHitStreak([
      { hit: false },
      { hit: true },
      { hit: true },
      { hit: true },
    ]),
    3
  );
});

test('多人局每轮最高者立马', () => {
  const game = createGame('u1', '甲', 1, 1000);
  assert.equal(addPlayer(game, 'u2', '乙', 1001).ok, true);
  assert.equal(startGame(game, 1002).ok, true);

  // 甲正投四中：10筹。
  const first = applyTurn(
    game,
    'u1',
    '甲',
    '正投',
    sequenceRandom([0.1, 0.1, 0.1, 0.1]),
    1003
  );
  assert.equal(first.ok, true);
  assert.equal(first.result.totalScore, 10);

  // 同轮不得重复。
  const duplicate = applyTurn(
    game,
    'u1',
    '甲',
    '正投',
    sequenceRandom([0.1, 0.1, 0.1, 0.1]),
    1004
  );
  assert.equal(duplicate.ok, false);

  // 乙背投一中（第一矢）：5+1=6筹。
  const second = applyTurn(
    game,
    'u2',
    '乙',
    '背投',
    sequenceRandom([0.1, 0.9, 0.9, 0.9]),
    1005
  );
  assert.equal(second.ok, true);
  assert.equal(second.result.totalScore, 6);
  assert.equal(second.gameEnded, true);
  assert.equal(game.players.find((p) => p.id === 'u1').horses, 1);
  assert.equal(game.players.find((p) => p.id === 'u2').horses, 0);
  assert.deepEqual(winners(game).map((p) => p.name), ['甲']);
});

test('同轮同分者各立一马，最终可并列', () => {
  const game = createGame('u1', '甲', 1, 1000);
  addPlayer(game, 'u2', '乙', 1001);
  startGame(game, 1002);

  const values = [0.1, 0.9, 0.9, 0.9]; // 正投1中且有初，共2筹
  applyTurn(game, 'u1', '甲', '正投', sequenceRandom(values), 1003);
  const result = applyTurn(
    game,
    'u2',
    '乙',
    '正投',
    sequenceRandom(values),
    1004
  );

  assert.equal(result.gameEnded, true);
  assert.equal(game.players[0].horses, 1);
  assert.equal(game.players[1].horses, 1);
  assert.equal(winners(game).length, 2);
});

test('最终排名先比马数，再以总筹破同马', () => {
  const game = {
    players: [
      { name: '甲', horses: 2, totalScore: 10 },
      { name: '乙', horses: 1, totalScore: 99 },
      { name: '丙', horses: 2, totalScore: 8 },
    ],
  };
  assert.deepEqual(winners(game).map((p) => p.name), ['甲']);
});

test('轮数解析和24小时失效边界正确', () => {
  assert.equal(parseRounds(''), 3);
  assert.equal(parseRounds('1'), 1);
  assert.equal(parseRounds('9'), 9);
  assert.equal(parseRounds('0'), null);
  assert.equal(parseRounds('10'), null);
  assert.equal(parseRounds('abc'), null);

  const game = createGame('u1', '甲', 3, 1000);
  game.updatedAt = 1000;
  assert.equal(isStale(game, 1000 + 23 * 60 * 60 * 1000), false);
  assert.equal(isStale(game, 1000 + 25 * 60 * 60 * 1000), true);
});
