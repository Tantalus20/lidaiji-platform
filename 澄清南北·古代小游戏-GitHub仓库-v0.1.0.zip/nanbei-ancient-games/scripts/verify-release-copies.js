const fs = require('node:fs');
const crypto = require('node:crypto');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const pairs = [
  ['plugins/chupu/nanbei-chupu.js', 'releases/v0.1.0/nanbei-chupu.js'],
  ['plugins/touhu/nanbei-touhu.js', 'releases/v0.1.0/nanbei-touhu.js'],
  ['plugins/feihualing/dist/nanbei-feihualing.js', 'releases/v0.1.0/nanbei-feihualing.js'],
];

function sha256(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

for (const [sourceRel, releaseRel] of pairs) {
  const source = path.join(root, sourceRel);
  const release = path.join(root, releaseRel);
  if (!fs.existsSync(source) || !fs.existsSync(release)) {
    throw new Error(`Missing release file: ${sourceRel} or ${releaseRel}`);
  }
  const a = sha256(source);
  const b = sha256(release);
  if (a !== b) throw new Error(`Release copy mismatch: ${releaseRel}`);
  console.log(`${releaseRel} ${a}`);
}
